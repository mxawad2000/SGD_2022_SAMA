package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class ChangePasswordInActivity2 extends AppCompatActivity {
    private EditText newpassword,confirmnewpassword;
    private ImageView back;
    private ImageView eye;
    private ImageView eye2;
    private Button save;

    private DatabaseReference databaseReference;
    private String oldpass;
    private String uphone;
    private String newpass;
    private ProgressBar simpleProgressBar ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password_in2);
        newpassword = findViewById(R.id.newpassword_change);
        confirmnewpassword = findViewById(R.id.confirmnewpassword_change);
        save = findViewById(R.id.saveButton_change);
        back = findViewById(R.id.backArrow_change);
        AccountManager currentUser= AccountManager.getInstance();
        eye = findViewById(R.id.eye_change);// change
        eye2 = findViewById(R.id.eye2_change);// change
        simpleProgressBar = (ProgressBar) findViewById(R.id.simpleProgressBar_changePass);



        eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(newpassword.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance())){
                    newpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }else{
                    newpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });

        eye2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(confirmnewpassword.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance())){
                    confirmnewpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }else{
                    confirmnewpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });




        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                simpleProgressBar.setVisibility(View.VISIBLE);


                newpass = newpassword.getText().toString();
                String newpass2 = confirmnewpassword.getText().toString();
                SecurityManager.HashMethod hashMethod = SecurityManager.getAppropriateHash();
                String hashPass = SecurityManager.getHashedPassword(hashMethod, newpass);

                if (TextUtils.isEmpty(newpass) || TextUtils.isEmpty(newpass2)) {
                    Toast.makeText(ChangePasswordInActivity2.this, "Empty Credentials!", Toast.LENGTH_SHORT).show();
                    simpleProgressBar.setVisibility(View.GONE);
                } else if (!newpass.equals(newpass2)) {

                    Toast.makeText(ChangePasswordInActivity2.this, "Passwords Doesn't Match!", Toast.LENGTH_SHORT).show();
                    simpleProgressBar.setVisibility(View.GONE);
                } else {
                    AccountManager.getInstance().setUserAccount(currentUser.getUserName(),hashPass, currentUser.getName(), String.valueOf(currentUser.getScore()),currentUser.getProfileImg());
                    //AccountManager.getInstance().setUsername(currentUser.getUserName());
                    //AccountManager.getInstance().setPassword(currentUser.getPassword());
                    FirebaseDatabase.getInstance().getReference("Users").child(currentUser.getUserName()).child("Password").setValue(hashPass);
                    Toast.makeText(ChangePasswordInActivity2.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                    simpleProgressBar.setVisibility(View.GONE);
                    Intent intent = new Intent();
                    intent.setClass(view.getContext(), EditProfileActivity.class);
                    view.getContext().startActivity(intent);






                }

            }
        });
    }
}