package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import edu.uaeu.samaapplication.Adapter.AllGoalsAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AllGoalsActivity extends AppCompatActivity {
    private TextView edit;
    private RecyclerView preferredGoals;
    private RecyclerView restGoals;
    private AllGoalsAdapter goalsAdapter;
    private List<String> interestList = new ArrayList<>();
    private List<Goal> goalsIconPreferred = new ArrayList<>();
    private List<Goal> goalsIconRest = new ArrayList<>();
    private String [] intarray = new String [17];
    private Goal [] GoalsMng = new Goal [17];
    private List<Goal> Goalsarray = new ArrayList<>();
    private ImageView arrow;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_goals);

        edit = findViewById(R.id.edit_interests);
        arrow = findViewById(R.id.return_arrow_allgoals);
        preferredGoals = findViewById(R.id.recycler_view_preferred);
        preferredGoals.setHasFixedSize(true);
        preferredGoals.setLayoutManager(new GridLayoutManager(this, 3));
        goalsAdapter = new AllGoalsAdapter(this , goalsIconPreferred );
        preferredGoals.setAdapter(goalsAdapter);
        restGoals = findViewById(R.id.recycler_view_rest);
        restGoals.setHasFixedSize(true);
        restGoals.setLayoutManager(new GridLayoutManager(this, 3));
        goalsAdapter = new AllGoalsAdapter(this , goalsIconRest );
        restGoals.setAdapter(goalsAdapter);
        getInterests();

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AllGoalsActivity.this, IntrestsActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });





    }

    private void getInterests() {
        FirebaseDatabase.getInstance().getReference("Users").child(AccountManager.getInstance().getUserName()).child("interest").addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    goalsIconPreferred.clear();
                    goalsIconRest.clear();
                    String interest = snapshot.getValue(String.class);
                    intarray = interest.split(",");
                    for(int i = 0; i<intarray.length; i++) {
                        if (!intarray[i].isEmpty()) {
                            // Log.i("My App", intList[i]);
                            interestList.add(intarray[i]);
                            Log.i("My App", "preferred Goals List: "+interestList.get(i));
                        }
                    }

                    //get the pictures of the Goals and save them in the goalsIcon
                    // (compare the interests with the Goal Manager description if same then put the photo inside the list)
                    Log.i("My App", "interest List size: "+interestList.size());
                    GoalsMng =GoalManager.getInstance().getGoals();
                    for(int i=0;i<GoalsMng.length;i++){
                        Goalsarray.add(GoalsMng[i]);
                    }
                    Log.i("My App", "Goals Array:  "+Goalsarray.size());
                    for(int i = 0 ; i< Goalsarray.size() ; i++){

                        for(int j = 0 ; j< interestList.size() ; j++) {

                            Log.i("My App", "Goals Array:  "+Goalsarray.size());

                             if (interestList.get(j).equals(Goalsarray.get(i).desc)) {
                                goalsIconPreferred.add(Goalsarray.get(i));

                            }

                        }
                    }
                    for(int i = 0 ; i< Goalsarray.size() ; i++){

                        if(!(goalsIconPreferred.contains(Goalsarray.get(i)))) {
                            goalsIconRest.add(Goalsarray.get(i));
                        }
                    }



                    Log.i("My App", "preferred Goals List: "+goalsIconPreferred);
                    Log.i("My App", "Rest Goals List: "+goalsIconRest);
                    goalsAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}