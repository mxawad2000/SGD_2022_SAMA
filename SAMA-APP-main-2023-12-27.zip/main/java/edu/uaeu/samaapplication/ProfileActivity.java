package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import edu.uaeu.samaapplication.Adapter.PhotoAdapter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    private RecyclerView recyclerViewPublic;
    private RecyclerView recyclerViewPrivate;
    private PhotoAdapter photoAdapter;
    private PhotoAdapter photoAdapter2;
    private List<Post> myPublicPhotolist;
    private List<Post> myPrivatePhotolist;

    private CircleImageView imageProfile;
    private ImageView logout;
    private ImageView setting;
    private TextView posts;
    private TextView score;
    private TextView username;
    private TextView name;
    private  ImageView back;

    private Button public_posts;
    private Button private_posts;

    //private TextView text;

    private String user;

    private int newScore;
    private String Score ;
    private String Point;


    String currentUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        Log.i("My App", "Profile Fragment 1" );

        currentUser = AccountManager.getInstance().getUserName();

       // text = findViewById(R.id.Text_profile);
        back = findViewById(R.id.back_profile);
        imageProfile = findViewById(R.id.image_profile);
        logout = findViewById(R.id.logout);
        setting = findViewById(R.id.setting);
        posts = findViewById(R.id.posts);
        score = findViewById(R.id.score);
        username = findViewById(R.id.username);
        name = findViewById(R.id.name);
        public_posts = findViewById(R.id.public_profile);
        private_posts =findViewById(R.id.private_profile);
        user = AccountManager.getInstance().getUserName();
        //profileId = AccountManager.getInstance().getUserName();

        recyclerViewPublic = findViewById(R.id.recycler_view_public);
        recyclerViewPublic.setHasFixedSize(true);
        recyclerViewPublic.setLayoutManager(new GridLayoutManager(this, 3));
        myPublicPhotolist = new ArrayList<>();
        photoAdapter = new PhotoAdapter(this,myPublicPhotolist);
        recyclerViewPublic.setAdapter(photoAdapter);

        recyclerViewPrivate = findViewById(R.id.recycler_view_private);
        recyclerViewPrivate.setHasFixedSize(true);
        recyclerViewPrivate.setLayoutManager(new GridLayoutManager(this, 3));
        myPrivatePhotolist = new ArrayList<>();
        photoAdapter2 = new PhotoAdapter(this,myPrivatePhotolist);
        recyclerViewPrivate.setAdapter(photoAdapter2);



        recyclerViewPublic.setVisibility(View.VISIBLE);
        recyclerViewPrivate.setVisibility(View.GONE);

        Log.i("My App", "Profile Fragment 2" );
        usernfo();
        Log.i("My App", "Profile Fragment 3" );
        userProfileImage();
        getPostCount();
        getScore();
        Log.i("My App", "Profile Fragment 4" );
        myPhotos();
        //Log.i("My App", "photo adapter: "+ myPublicPhotolist.size());





        // no need for it because we used another xml and activity for viewing other user profile


        public_posts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                public_posts.setTextColor(view.getContext().getResources().getColor(R.color.black));
                private_posts.setTextColor(view.getContext().getResources().getColor(R.color.gray));
                recyclerViewPrivate.setVisibility(View.GONE);
                recyclerViewPublic.setVisibility(View.VISIBLE);


            }
        });

        private_posts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                private_posts.setTextColor(view.getContext().getResources().getColor(R.color.black));
                public_posts.setTextColor(view.getContext().getResources().getColor(R.color.gray));
                recyclerViewPrivate.setVisibility(View.VISIBLE);
                recyclerViewPublic.setVisibility(View.GONE);


            }
        });


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("My App", "Logout onclick: In" );
                AccountManager.getInstance().logOut();
                Intent intent = new Intent(view.getContext(), FirstPage.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("LOGOUT", true);
                startActivity(intent);
                //getActivity().onBackPressed();
                //requireActivity().finish();
                Log.i("My App", "Finish....." );
            }
        });

        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("My App", "Settings onclick: In" );
                Intent intent = new Intent(view.getContext(), EditProfileActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_profile);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if(id == R.id.nav_home) {
                    startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if( id == R.id.nav_search) {
                    startActivity(new Intent(getApplicationContext(), SearchActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if(id == R.id.nav_add) {
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if(id == R.id.nav_heart) {
                    startActivity(new Intent(getApplicationContext(), NotificationActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if(id == R.id.nav_profile){
                        return true;
                }
                return false;
            }
        });

    }

    private void myPhotos() { // we need to add here a parameter to see if the user is he owner of the account he can view the private images and vice versa
        recyclerViewPublic.setVisibility(View.VISIBLE);

        Log.i("My App", "Profile Fragment 5 : myPhotos method In" );
        FirebaseDatabase.getInstance().getReference().child("Users").child(currentUser).child("posts").addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    myPrivatePhotolist.clear();
                    myPublicPhotolist.clear();
                    Log.i("My App", "Profile Fragment 6 : Snapshot");
                    Log.i("My App", "Profile Fragment snapshot: " + snapshot.getValue());

                    for (DataSnapshot s : snapshot.getChildren()) {
                        Log.i("My App", "Profile Fragment 7 : Snapshot s ");
                        Log.i("My App", "Profile Fragment 8 data snapshot ALL: " + s.getValue());
                        Map<String, String> m = (Map<String, String>) s.getValue();
                        Post post = (snapshot.getValue(Post.class));
                        //  Log.i("My App", "datasnapshot3333: " +post.toString());
                        post.setAction(m.get("Action"));
                        post.setGoal(m.get("Goal"));
                        post.setDescription(m.get("Description"));
                        post.setLike(m.get("Like"));
                        post.setGoalId(m.get("Goal ID"));
                        post.setPrivate(Boolean.valueOf(m.get("Private")));
                        post.setPoint(m.get("Point"));
                        post.setPublisher(m.get("Publisher"));
                        post.setDisLike(m.get("Dislike"));
                        post.setPostId(m.get("Post ID"));
                        post.setImage(m.get("Image"));
                        post.setLink(m.get("Link"));
                        Log.i("My App", "Profile Fragment IMAGE: " + post.getImage());
                        if(post.getImage() != null) {
                            byte[] decodedString = Base64.decode(post.getImage(), Base64.DEFAULT);
                            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                            post.setImageBitmap(decodedByte);
                            Log.i("My App", "Profile Fragment IMAGE: " + post.getImageBitmap());
                        }else{
                                Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.img_not_available);
                                post.setImageBitmap(largeIcon);
                        }

                        if (post.getPrivate()) {
                            Log.i("My App", "Profile Fragment 9 : getPublisher ");
                            myPrivatePhotolist.add(post);
                        }else{
                            myPublicPhotolist.add(post);
                            Log.i("My App","adding new post...................................");
                        }

                    }



                    Log.i("My App", "Profile Fragment public post list size  : " + myPublicPhotolist.size());
                    Collections.reverse(myPublicPhotolist);
                    Collections.reverse(myPrivatePhotolist);
                    photoAdapter.notifyDataSetChanged();
                    photoAdapter2.notifyDataSetChanged();
                    Log.i("My App", "Profile Fragment After Notify public posts:< " + myPublicPhotolist.size()+"Private posts: "+myPrivatePhotolist + " > adapter size<" + photoAdapter.getItemCount() + " >..... ");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void userProfileImage() {

        FirebaseDatabase.getInstance().getReference().child("Users").child(currentUser).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {

                    User user = snapshot.getValue(User.class);
                    Map<String, String> m = (Map<String, String>) snapshot.getValue();
                    if (m.get("ProfileImg").equals("default")) {
                        Log.i("My App", "From DB Image - ProfileFragment : " + AccountManager.getInstance().getProfileImg());
                        imageProfile.setImageResource(R.drawable.imgpro);

                    } else {
                        Log.i("My App", "User has a ProfileImg- ProfileFragment: " + m.get("ProfileImg"));
                        byte[] decodedString = Base64.decode(m.get("ProfileImg"), Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        if (bitmap != null)
                            imageProfile.setImageBitmap(bitmap);

                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void getScore() {
        FirebaseDatabase.getInstance().getReference().child("Users").child(currentUser).child("Score").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    score.setText(snapshot.getValue().toString());
                }else{
                    score.setText("DNE");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void getPostCount() {
        FirebaseDatabase.getInstance().getReference().child("Users").child(currentUser).child("posts").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    posts.setText("" + snapshot.getChildrenCount());
                }else{
                    posts.setText("0");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void usernfo() {
        FirebaseDatabase.getInstance().getReference().child("Users").child(currentUser).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                Log.i("My App", "UserInfo: IN ");
                if(snapshot.exists()) {
                    Map<String, String> m = (Map<String, String>) snapshot.getValue();
                    User user = (snapshot.getValue(User.class));
                    Log.i("My App", "Username: "+m.get("Username")+" Name: "+m.get("Name"));
                    user.setUsername(m.get("Username"));
                    user.setName(m.get("Name"));

                    // User user = snapshot.getValue(User.class);
                    username.setText("@"+user.getUsername());
                    name.setText(user.getName());

                }else{
                    Log.i("My App","Snapshot is Empty>>>>");
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


}