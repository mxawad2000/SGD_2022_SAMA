package edu.uaeu.samaapplication.util;

import android.content.res.AssetManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import edu.uaeu.samaapplication.MyApp;

public class AssetsMgr {
   private static AssetsMgr Instance = new AssetsMgr();
   public static AssetsMgr getInstance(){ return Instance;}
   private Map<String,String> goalsDescMap = new HashMap<>();
   private AssetsMgr(){init();}
   private void init(){
      AssetManager am = MyApp.getAppContext().getAssets();
      /*
      try{
         BufferedReader br = new BufferedReader( new InputStreamReader( am.open("sdg_goals.txt")));
         String line = null;
         String goal = null;
         StringBuffer text = new StringBuffer();
         while((line = br.readLine()) != null){
            if(line.startsWith("#")){
               if(goal != null){
                  goalsDescMap.put(goal,text.toString());
                  text.delete(0,text.length());
                  goal = line.substring(1);
               }else {
                  goal = line.substring((1));
               }
            }else{
               text.append(line).append("\n");
            }
         }
         goalsDescMap.put(goal,text.toString());

      }catch(Exception ex){
         Log.i(MyApp.LOG_STR,"error:" + ex.getMessage());
      }
       */
   }

}
