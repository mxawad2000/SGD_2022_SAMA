package edu.uaeu.samaapplication.util;

import edu.uaeu.samaapplication.MyApp;

public class GenUtil {
   public  static int getResourceByName(String aString,String type) {
      String packageName = MyApp.getAppContext().getPackageName();
      int resId = MyApp.getAppContext().getResources().getIdentifier(aString, type, packageName);
      return resId;
   }
   public static String[] getActionsByGoal(String goal){
      int resId = getResourceByName(goal,"array");
      return MyApp.getAppContext().getResources().getStringArray(resId);
   }
   public static String[] getGoalsInfo(){
      int resId = getResourceByName("GoalsInfoArray","array");
      return MyApp.getAppContext().getResources().getStringArray(resId);
   }
   public static String[] getGoals(){
      int resId = getResourceByName("Goals","array");
      return MyApp.getAppContext().getResources().getStringArray(resId);
   }

}
