package edu.uaeu.samaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class NewPasswordActivity extends AppCompatActivity {


    private EditText newpassword,confirmnewpassword;
    private ImageView back;
    private ImageView eye1;
    private ImageView eye2;

    private Button signInButton;
    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    private String oldpass;
    private String uphone;
    private String newpass;
    private ProgressBar simpleProgressBar ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_password);

        newpassword = findViewById(R.id.newpassword);
        confirmnewpassword = findViewById(R.id.confirmnewpassword);
        signInButton = findViewById(R.id.signInButton);
        back = findViewById(R.id.backArrow_newPass);
        eye1=findViewById(R.id.eye_newPass);
        eye2=findViewById(R.id.eye2_newPass);
        mAuth = FirebaseAuth.getInstance();
        simpleProgressBar = (ProgressBar) findViewById(R.id.simpleProgressBar_newPass);


        AccountManager user1= AccountManager.getInstance();



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        eye1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(newpassword.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance())){
                    newpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }else{
                    newpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });

        eye2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(confirmnewpassword.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance())){
                    confirmnewpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }else{
                    confirmnewpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });


        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                simpleProgressBar.setVisibility(View.VISIBLE);

                //Log.i("My App", "user1 password"+user1.getPassword());

                Bundle extras = getIntent().getExtras();
                if (extras != null) {
                    uphone = extras.getString("phone");
                    //The key argument here must match that used in the other activity
                }
                Log.i("My App", "Extra info: " + uphone);


                newpass = newpassword.getText().toString();
                String newpass2 = confirmnewpassword.getText().toString();
                SecurityManager.HashMethod hashMethod = SecurityManager.getAppropriateHash();
                String hashPass = SecurityManager.getHashedPassword(hashMethod, newpass);

                if (TextUtils.isEmpty(newpass) || TextUtils.isEmpty(newpass2)) {
                    Toast.makeText(NewPasswordActivity.this, "Empty Credentials!", Toast.LENGTH_SHORT).show();
                    simpleProgressBar.setVisibility(View.GONE);

                } else if (!newpass.equals(newpass2)) {
                    Toast.makeText(NewPasswordActivity.this, "Passwords Doesn't Match!", Toast.LENGTH_SHORT).show();
                    simpleProgressBar.setVisibility(View.GONE);
                } else {

                    databaseReference = FirebaseDatabase.getInstance().getReference("Users");
                    Query userCheck = databaseReference.orderByChild("Phone").equalTo(uphone);
                    userCheck.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            Log.i("My App", "Snapshot value: " + snapshot.getValue());
                            if (snapshot.exists()) {
                                User user2 = new User();
                                Log.i("My App", "snapshot exists!");
                                for (DataSnapshot s : snapshot.getChildren()) {
                                    Map<String, String> m = (Map<String, String>) s.getValue();
                                    Log.i("My App", "Hash Map works!");
                                    user2 = (s.getValue(User.class));
                                    Log.i("My App", "User works!"+ s.getValue());
                                    //  Log.i("My App", "datasnapshot3333: " +post.toString());
                                    user2.setUsername(m.get("Username"));
                                    Log.i("My App", "Set username works!: " + user2.getUsername());
                                    user2.setName(m.get("Name"));
                                    Log.i("My App", "Set name works!: " + user2.getName());
                                    user2.setScore(m.get("Score"));
                                    Log.i("My App", "Set score works!: " + user2.getScore());
                                    user2.setImage(m.get("ProfileImg"));
                                    Log.i("My App", "Set image profile works!: " + user2.getImage());

                                }
                                AccountManager.getInstance().setUserAccount(user2.getUsername(),hashPass, user2.getName(), user2.getScore(),user2.getImage());
                                FirebaseDatabase.getInstance().getReference("Users").child(user2.getUsername()).child("Password").setValue(hashPass);
                                Toast.makeText(NewPasswordActivity.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                                //startActivity(new Intent(NewPasswordActivity.this, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
                                simpleProgressBar.setVisibility(View.GONE);
                                Intent intent = new Intent();
                                intent.setClass(view.getContext(), HomeActivity.class);
                                view.getContext().startActivity(intent);

                            } else {
                                Log.i("My App", "snapshot doesn't exists!");
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }

            }
        });

    }

}



