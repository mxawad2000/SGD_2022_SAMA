package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import edu.uaeu.samaapplication.Adapter.GoalAdapter;
import edu.uaeu.samaapplication.Adapter.UserAdapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;


import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SearchActivity extends AppCompatActivity {
    private RecyclerView recyclerViewGoals;
    private RecyclerView recyclerViewUsers;
    private Toolbar toolbar;
    private UserAdapter userAdapter;
    private GoalAdapter goalsAdapter;
    private List<User> mUsers;
    private List<Goal> mGoals;
    private Goal [] Goals;
    private Button goalsBtn;
    private Button usersBtn;
    private Button socialBtn;
    String goalid;
    private AutoCompleteTextView search_bar;
    private boolean isSocialBar = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        toolbar = findViewById(R.id.toolbar);
        recyclerViewUsers = findViewById(R.id.recycler_view_users);
        recyclerViewUsers.setHasFixedSize(true);
        recyclerViewUsers.setLayoutManager(new LinearLayoutManager(this));
        mUsers = new ArrayList<>();
        userAdapter = new UserAdapter(this , mUsers , true);
        recyclerViewUsers.setAdapter(userAdapter);
        //goal menu
        recyclerViewGoals = findViewById(R.id.recycler_view_goals);
        recyclerViewGoals.setHasFixedSize(true);
        recyclerViewGoals.setLayoutManager(new LinearLayoutManager(this));
        mGoals = new ArrayList<>();
        goalsAdapter = new GoalAdapter(this , mGoals );
        recyclerViewGoals.setAdapter(goalsAdapter);
        //user menu
        search_bar = findViewById(R.id.search_bar);
        usersBtn = findViewById(R.id.users);
        goalsBtn = findViewById(R.id.goals);
        this.socialBtn = findViewById(R.id.social_media);

        SharedPreferences prefs = this.getSharedPreferences("PREFS" , Context.MODE_PRIVATE);
        goalid = prefs.getString("goalid" , "none");
        getNrPosts();
        ImageView searchIcon = findViewById(R.id.ic_search);
        searchIcon.setOnClickListener( (View v) -> {
            String s = search_bar.getText().toString();
            if(s.trim().isEmpty()) return;
            if(!isSocialBar) {
                searchUser(s);
            }else{
                Intent intent = new Intent(SearchActivity.this, UAEActivity.class);
                intent.putExtra("q",s);
                startActivity(intent);
            }
        });
        search_bar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //searchUser(s.toString());
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
            @Override
            public void afterTextChanged(Editable s) {
               /*
                if(!isSocialBar) {
                    searchUser(s.toString());
                }else{
                    Intent intent = new Intent(SearchActivity.this, UAEActivity.class);
                    intent.putExtra("q",s.toString());
                    startActivity(intent);
                }

                */
            }
        });

        usersBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recyclerViewGoals.setVisibility(View.GONE);
                toolbar.setVisibility(View.VISIBLE);
                //Log.i("My App", "Users Button Clicked");
                goalsBtn.setTextColor(view.getContext().getResources().getColor(R.color.gray));
                socialBtn.setTextColor(view.getContext().getResources().getColor(R.color.gray));
                usersBtn.setTextColor(view.getContext().getResources().getColor(R.color.black));
                isSocialBar=false;
            }
        });
        socialBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toolbar.setVisibility(View.VISIBLE);
                recyclerViewGoals.setVisibility(View.GONE);
                recyclerViewUsers.setVisibility(View.GONE);
                //Log.i("My App", "Users Button Clicked");
                goalsBtn.setTextColor(view.getContext().getResources().getColor(R.color.gray));
                usersBtn.setTextColor(view.getContext().getResources().getColor(R.color.gray));
                socialBtn.setTextColor(view.getContext().getResources().getColor(R.color.black));
                isSocialBar=true;
            }
        });
        goalsBtn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onClick(View view) {
                toolbar.setVisibility(View.GONE);
                recyclerViewUsers.setVisibility(View.GONE);
                recyclerViewGoals.setVisibility(View.VISIBLE);
                goalsBtn.setTextColor(view.getContext().getResources().getColor(R.color.black));
                usersBtn.setTextColor(view.getContext().getResources().getColor(R.color.gray));
                socialBtn.setTextColor(view.getContext().getResources().getColor(R.color.gray));
                isSocialBar=false;
                Goals = GoalManager.getInstance().getGoals();
                for(int i = 0; i<Goals.length;i++){
                    //Log.i("My App","getGoals: "+Goals[i].getDesc());
                    mGoals.add(Goals[i]);
                }
                goalsAdapter.notifyDataSetChanged();

            }
        });



        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_search);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if( id ==  R.id.nav_home) {
                    startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if(id == R.id.nav_search) {

                    return true;
                }
                if (id == R.id.nav_add) {
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if( id == R.id.nav_heart) {
                    startActivity(new Intent(getApplicationContext(), NotificationActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if( id ==  R.id.nav_profile) {
                    startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                return false;
            }
        });


    }

    private void getNrPosts() {

    }

    private void searchUser (String s) {
        recyclerViewUsers.setVisibility(View.VISIBLE);
        Query query = FirebaseDatabase.getInstance().getReference("Users").orderByChild("Username").startAt(s)
                .endAt(s + "\uf8ff");
        query.addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    mUsers.clear();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Map<String, String> m = (Map<String, String>) snapshot.getValue();
                        User user = snapshot.getValue(User.class);
                        //  Log.i("My App", "datasnapshot3333: " +post.toString());
                        user.setUsername(m.get("Username"));
                        user.setName(m.get("Name"));
                        user.setImage(m.get("ProfileImg"));
                        if (!user.getImage().equals("default")) {
                            byte[] decodedString = Base64.decode(user.getImage(), Base64.DEFAULT);
                            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                            user.setImageBitmap(decodedByte);
                        }
                        mUsers.add(user);
                    }
                    userAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    private String getGoal(String enteredGoal) {
        Goal[] goals;
        goals = GoalManager.getInstance().getGoals();
        for(int i=0;i<goals.length;i++) {
            //Log.i("My App","For Loop: In" + goals[i].getId());
            if ((goals[i].getDesc()).contains(enteredGoal)){
              //  Log.i("My App","Goal Desc Array: "+goals[i].getDesc());
                return goals[i].getId();
            }

        }
        return "NO!!!!!!";
    }



    @Override
    public void onStart() {
        super.onStart();

    }
}