package edu.uaeu.samaapplication;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import edu.uaeu.samaapplication.Adapter.PostAdapter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PostDetailActivity extends AppCompatActivity {

    //private static final android.R.attr R = ;
    private String postid;
    private String author;
    private RecyclerView recyclerView;
    private PostAdapter postAdapter;
    private List<Post> postList;
    private List<User> userList;
    private ImageView back_arrow;



    /*
    @Override
    public void onBackPressed(){
        FragmentManager fm = getFragmentManager();
        if (fm.getBackStackEntryCount() > 0) {
            Log.i("MainActivity", "popping backstack");
            fm.popBackStack();
        } else {
            Log.i("MainActivity", "nothing on backstack, calling super");

        }
    }

     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);

        //SharedPreferences sharedPreferences = getContext().getSharedPreferences("MyTerraApplication.CIT.AE" , Context.MODE_PRIVATE);

        //


        back_arrow = findViewById(R.id.back_arrow);

        postid = this.getSharedPreferences("PREFS", Context.MODE_PRIVATE).getString("postid", "none");
        author = this.getSharedPreferences("PREFS", Context.MODE_PRIVATE).getString("author", "none");
        Log.i("My App", "PostDetailFragment postid: "+ postid);
        Log.i("My App", "PostDetailFragment author: "+ author);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        postList = new ArrayList<>();
        userList = new ArrayList<>();
        postAdapter = new PostAdapter(this , postList, userList);
        recyclerView.setAdapter(postAdapter);

        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("My App", "Pressed **  ");
                /*
                Intent intent = new Intent(view.getContext(), ProfileFragment.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);

                 */
                //getActivity().getFragmentManager().popBackStack();
                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ProfileFragment()).commit();
                //findNavController().popBackStack();
                // onBackPressed();

                // This callback will only be called when MyFragment is at least Started.
                //setupOnBackPressed();

                // The callback can be enabled or disabled here or in handleOnBackPressed()

                //getActivity().getSupportFragmentManager().popBackStackImmediate();
              //  getActivity().getSupportFragmentManager().popBackStack(); used in Fragment this way
                finish();

                //findNavController().popBackStack().

            }


        });

        readPost();

    }

    private void readPost() {
        Log.i("My App", "Author: "+ author);
        Log.i("My App", "post id: "+ postid);
        // DatabaseReference referenc1e = FirebaseDatabase.getInstance().getReference("Goals").orderByChild(postid);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users/"+author+"/posts/"+postid);
        Query userCheck = reference.orderByChild(postid);
        Log.i("My App", String.valueOf(userCheck));
        Log.i("My App", "PostDetailFragment - post id : " + postid);
        Log.i("My App", "PostDetailFragment - author : " + author);
        //Here...

        //userCheck.addListenerForSingleValueEvent
        FirebaseDatabase.getInstance().getReference("Users/"+author+"/posts/"+postid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.i("My App", "Data snapshot where should we have a loop: "+ dataSnapshot.getValue());
                postList.clear();
                //for(DataSnapshot s : dataSnapshot.getChildren()) {
                //for(DataSnapshot ss : s.getChildren()) {
                if(dataSnapshot.exists()) {
                    Log.i("My App", "Data snapshot inside  the loop: " + dataSnapshot.getValue());

                    Map<String, String> m = (Map<String, String>) dataSnapshot.getValue();
                    Post post = (dataSnapshot.getValue(Post.class));
                    //  Log.i("My App", "datasnapshot3333: " +post.toString());
                    Log.i("My App", "Data snapshot inside  the loop post Id: " + m.get("Post ID"));
                    Log.i("My App", "Data snapshot inside  the loop Action: " + m.get("Action"));
                    post.setAction(m.get("Action"));
                    post.setGoal(m.get("Goal"));
                    post.setDescription(m.get("Description"));
                    post.setLike(m.get("Like"));
                    post.setGoalId(m.get("Goal ID"));
                    post.setPrivate(Boolean.valueOf(m.get("Private")));
                    post.setPoint(m.get("Point"));
                    post.setPublisher(m.get("Publisher"));
                    post.setDisLike(m.get("Dislike"));
                    post.setPostId(m.get("Post ID"));
                    post.setImage(m.get("Image"));
                    post.setLink(m.get("Link"));
                    Log.i("My App", "Profile Fragment IMAGE: " + post.getImage());
                    if(post.getImage() != null) {
                        byte[] decodedString = Base64.decode(post.getImage(), Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        post.setImageBitmap(decodedByte);
                    }else{
                        Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.img_not_available);
                        post.setImageBitmap(largeIcon);
                    }
                    Log.i("My App", "Profile Fragment IMAGE: " + post.getImageBitmap());
                    //
                    postList.add(post);
                    //}
                    //}
                        Log.i("My App", "Home Fragment - postsAuthors size:  "+ postList.size());

                        FirebaseDatabase.getInstance().getReference("Users").child(author).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.exists()){
                                    Log.i("My App", "Home Fragment - inside users snapshot ");
                                    Map<String,String> map = (Map<String, String>) snapshot.getValue();
                                    User user = (snapshot.getValue(User.class));
                                    user.setUsername(map.get("Username"));
                                    user.setName(map.get("Name"));
                                    user.setScore(String.valueOf(map.get("Score")));
                                    user.setImage(map.get("ProfileImg"));
                                    byte[] decodedString = Base64.decode(user.getImage(), Base64.DEFAULT);
                                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                    user.setImageBitmap(bitmap);
                                    Log.i("My App", "Home Fragment - Username: " + user.getUsername() + " Name: " + user.getName() + " ProfImage:  "+ user.getImage()+ " Score: "+user.getScore());

                                    userList.add(user);
                                        Log.i("My App", "Home Fragment - Users inside user snapshot : "+userList);


                                }else{
                                    Log.i("My App", "Home Fragment - before Notify users list size:<" + userList.size() + "> adapter size<" + postAdapter.getItemCount() + " >..... ");
                                    //postAdapter.notifyDataSetChanged();
                                    Log.i("My App", "Home Fragment - After Notify users list size: <" + userList.size() + "> adapter size<" + postAdapter.getItemCount() + " >..... ");
                                }

                                if(!postList.isEmpty()) Log.i("My App", "Home Fragment - post list  : " + postList.get(0).toString());
                                postAdapter.notifyDataSetChanged();
                                Log.i("My App", "Home Fragment - After Notify:<" + postList.size() + "> adapter size<" + postAdapter.getItemCount() + " >..... ");


                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });



                    //postAdapter.notifyDataSetChanged();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}