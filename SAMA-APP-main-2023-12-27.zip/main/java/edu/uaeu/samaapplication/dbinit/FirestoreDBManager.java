package edu.uaeu.samaapplication.dbinit;

import android.util.Log;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import edu.uaeu.samaapplication.Goal;
import edu.uaeu.samaapplication.MyApp;
import edu.uaeu.samaapplication.R;

public class FirestoreDBManager {
   HashMap<String, Goal> goalDB = new HashMap<>();
   private static FirestoreDBManager Instance = new FirestoreDBManager();
   FirebaseFirestore db ;
   private FirestoreDBManager(){
      db = FirebaseFirestore.getInstance();
      init();
   }
   private void aaaa(){
      db = FirebaseFirestore.getInstance();
      CollectionReference goalsRef = db.collection("Goals");
      //read all the goals along with their actions..
      String[] goals = MyApp.getAppContext().getResources().getStringArray(R.array.Goals);
      int index = 1;
      HashMap<String,Object> goalsMap = new HashMap<>();
      for(String goal : goals){
         goalsMap.clear();
         String goalStr = goal.substring(3).trim();
         goalsMap.put("id",index+"");
         String goalID = "Goal" + index;
         String[] actions = MyApp.getAppContext().getResources().getStringArray(
                 getResId(goalID,R.array.class));
         goalsMap.put("actions", Arrays.asList(actions));
         goalsMap.put("name",goalStr);

         //Log.i("My App","Goal:" + goal + "-->actions:" + Arrays.toString(actions));
         index++;
         goalsRef.document(goalID).set(goalsMap);
      }
   }
   private void setGoalsLocally(){
      this.goalDB.clear();
      db = FirebaseFirestore.getInstance();
      CollectionReference goalsRef = db.collection("Goals");
      //read all the goals along with their actions..
      String[] goals = MyApp.getAppContext().getResources().getStringArray(R.array.Goals);
      int index = 1;
      for(String goal : goals){
         String goalStr = goal.substring(3).trim();
         String goalID = "Goal" + index;
         String[] actions = MyApp.getAppContext().getResources().getStringArray(
                 getResId(goalID,R.array.class));
         Goal g = new Goal();
         g.setDesc(goalStr);
         g.setId(index+"");
         g.setInfo("");
         g.setLink("");
         g.setLogo(0);
         g.setLogoLapel(0);
         g.setSqrLogo(0);
         g.addActions(actions);
         //Log.i("My App","Goal:" + goal + "-->actions:" + Arrays.toString(actions));
         index++;
         goalsRef.document(goalID).set(g);
         this.goalDB.put(g.getId(),g);
      }
   }
   private void init(){
      db = FirebaseFirestore.getInstance();
      CollectionReference goalsRef = db.collection("Goals");
      db.collection("Goals").get().addOnCompleteListener(task -> {
         if (task.isSuccessful()) {
            for (QueryDocumentSnapshot document : task.getResult()) {
               Goal g = new Goal();
               Map<String,Object> data = document.getData();
               g.setDesc((String) data.get("name"));
               g.setId((String) data.get("id"));
               g.setInfo("");
               g.setLink("");
               g.setLogo(0);
               g.setLogoLapel(0);
               g.setSqrLogo(0);
               g.addActions((List<String>)data.get("actions"));
               Log.i("My App","goal:" + g.toString());
               this.goalDB.put(g.getId(),g);
            }
            if(this.goalDB.isEmpty()) setGoalsLocally();
         } else {
            Log.w("My App", "Error getting documents.", task.getException());
         }
      });
   }

   public static FirestoreDBManager getInstance(){ return Instance;}

   public static int getResId(String resName, Class<?> c) {
      try {
         Field idField = c.getDeclaredField(resName);
         return idField.getInt(idField);
      } catch (Exception e) {
         e.printStackTrace();
         return -1;
      }
   }

}
