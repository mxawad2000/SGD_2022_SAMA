package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import edu.uaeu.samaapplication.Adapter.PostAdapter;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class HomeActivity extends AppCompatActivity {
    private RecyclerView recyclerViewPosts;
    private PostAdapter postAdapter;
    private List<Post> postList;
    private List<String> intrestList;
    private List<User> users;
    private List<String> postsAuthors;
    // private String [] n = new String[17];
    private String imageDecoded;
    private ImageView ranking;
    private ImageView goals;
    private ImageView uae;
    private Parcelable recyclerViewState;
    private LinearLayoutManager linearLayoutManager;

    private Post post;
    private Map<String,String> m;
    //private TextView text;

    private void encodeBitmapAndSaveToFirebase(Bitmap photo) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        photo.compress(Bitmap.CompressFormat.PNG, 100, baos);
        imageDecoded = new String (Base64.decode(baos.toByteArray(), Base64.DEFAULT));

    }
    public void refresh() {

        Intent intent = new Intent(this, HomeActivity.class);
        ((Activity)this).overridePendingTransition(0, 0);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        // ((Activity)mContext).finish();
        ((Activity)this).overridePendingTransition(0, 0);
        this.startActivity(intent) ;
        // this.notifyItemRangeChanged(0,this.getItemCount());
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
       // text = findViewById(R.id.Text_home);
        ranking = findViewById(R.id.imgRankIcon);
        goals = findViewById(R.id.imgGoalsIcon);
        uae = findViewById(R.id.imgFlag);
        recyclerViewPosts = findViewById(R.id.recycler_view_posts);
        recyclerViewPosts.setHasFixedSize(true);
         linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);
        linearLayoutManager.setReverseLayout(true);
        recyclerViewPosts.setLayoutManager(linearLayoutManager);
        postList = new ArrayList<>();
        intrestList = new ArrayList<>();
        postsAuthors = new ArrayList<>();
        users = new ArrayList<>();
        postAdapter = new PostAdapter(this,postList, users);
        recyclerViewPosts.setAdapter(postAdapter);

        checkUserIntrests();
        Log.i("My App","Home Fragment return View ");

        ranking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(view.getContext(), RankingActivity.class);
                view.getContext().startActivity(intent);
            }
        });

        goals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(view.getContext(), AllGoalsActivity.class);
                view.getContext().startActivity(intent);
            }
        });

        uae.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(view.getContext(), UAEActivity.class);
                view.getContext().startActivity(intent);
            }
        });
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_home);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemid = item.getItemId();
                if(itemid == R.id.nav_home){
                    refresh();
                    return true;
                }
                if(itemid == R.id.nav_search){
                    startActivity(new Intent(getApplicationContext(),SearchActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                if(itemid == R.id.nav_add) {
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if(itemid == R.id.nav_heart) {
                    startActivity(new Intent(getApplicationContext(), NotificationActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if( itemid == R.id.nav_profile) {
                    startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                 return false;
            }
        });
        TextView userNameTV = findViewById(R.id.username);
        userNameTV.setText("Hello " + AccountManager.getInstance().getName());
    }

    private void checkUserIntrests() {
        Log.i("My App","Home Fragment 2 ");
        FirebaseDatabase.getInstance().getReference().child("Users")
                .child(AccountManager.getInstance().getUserName()).child("interest").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()) {
                            Log.i("My App", "Getting interest");
                            Log.i("My App", "datasnapshot: " + dataSnapshot.getKey());
                            String s1 = FirebaseDatabase.getInstance().getReference().child("Users").child(AccountManager.getInstance().getUserName()).child("interest").toString();
                            //dataSnapshot.getValue();
                            Log.i("My App", "datasnapshot: " + s1);
                            Log.i("My App", "datasnapshot222: " + dataSnapshot.getValue());


                            //intrestList.clear();
                            String[] n = dataSnapshot.getValue().toString().split(",");
                            intrestList = Arrays.asList(n);
                            Log.i("My App", "Added......................................................");
                            Log.i("My App", "List contains: " + intrestList);
                           readPosts();


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void readPosts() {
        Log.i("My App", "Home Fragment 3 ");
        postList.clear();

        for (int i = 0; i < intrestList.size() ; i++){
            List<Post> postList2 = new ArrayList<>();
            Log.i("My App", "loop for database: "+intrestList.get(i));
            String goalID = GoalManager.getInstance().getGoalID(intrestList.get(i));
            Log.i("My App", "Goal ID: "+goalID);
            FirebaseDatabase.getInstance().getReference().child("Goals/"+goalID+"/").addValueEventListener(new ValueEventListener() {
                @SuppressLint("NotifyDataSetChanged")
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Log.i("My App", "DATA was changed, capture change in likes.............................");
                    if (dataSnapshot.exists()){
                        Log.i("My App", "Home Fragment - Reading Posts from DB ");

                        Log.i("My App", "Home Fragment -  datasnapshot3333: " + dataSnapshot.getValue());
                        Log.i("My App", "Home Fragment - Interest List: " + intrestList);

                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Log.i("My App", "Home Fragment - H1 ");
                            //Log.i("My App","Home Fragment - datasnapshotALL: "+snapshot.getValue());
                            m = (Map<String, String>) snapshot.getValue();
                            post = (snapshot.getValue(Post.class));
                            //  Log.i("My App", "datasnapshot3333: " +post.toString());
                            post.setAction(m.get("Action"));
                            post.setGoal(m.get("Goal"));
                            post.setDescription(m.get("Description"));
                            post.setLike(m.get("Like"));
                            post.setGoalId(m.get("Goal ID"));
                            post.setPrivate(Boolean.valueOf(m.get("Private")));
                            post.setPoint(m.get("Point"));
                            post.setPublisher(m.get("Publisher"));
                            post.setDisLike(m.get("Dislike"));
                            post.setPostId(m.get("Post ID"));
                            post.setLink(m.get("Link"));
                            if(post.getImage() != null) {
                                byte[] decodedString = Base64.decode(post.getImage(), Base64.DEFAULT);
                                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                post.setImageBitmap(decodedByte);
                            }else{
                                Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.img_not_available);
                                post.setImageBitmap(largeIcon);
                            }
                            if(!postsAuthors.contains(post.getPublisher())){
                                postsAuthors.add(post.getPublisher());
                                Log.i("My App", "Home Fragment - posts Authors list: " + postsAuthors);
                            }


                            //Log.i("My App", "Home Fragment - ---------------------------------------------------------IMAGE: " + post.getImageBitmap());
                            Log.i("My App", "Home Fragment - H2 ");
                            for (String id : intrestList) {
                                Log.i("My App", "Home Fragment - H3 ");
                                if ((post.getGoal().contains(id))&& (!post.getPrivate())) {
                                    if(!postList2.contains(post)) postList2.add(post);
                                }
                            }
                        }

                        //postList.addAll(postList2);
                        for(Post p : postList2){
                            if(postList.contains(p)) continue;
                            postList.add(p);
                        }
                        Collections.reverse(postList);

                        for(int j = 0 ; j < postsAuthors.size(); j ++){
                            Log.i("My App", "Home Fragment - postsAuthors size:  "+ postsAuthors.size());
                            Log.i("My App", "Home Fragment - String s : " + j);
                            FirebaseDatabase.getInstance().getReference("Users").child(postsAuthors.get(j)).addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {

                                    if(snapshot.exists()){
                                        Log.i("My App", "Home Fragment - inside users snapshot ");
                                        Map<String,String> map = (Map<String, String>) snapshot.getValue();
                                        User user = (snapshot.getValue(User.class));
                                        user.setUsername(map.get("Username"));
                                        user.setName(map.get("Name"));
                                        user.setScore(String.valueOf(map.get("Score")));
                                        user.setImage(map.get("ProfileImg"));
                                        if(!user.getImage().equals("default")){
                                            //-//
                                            byte[] decodedString = Base64.decode(user.getImage(), Base64.DEFAULT);
                                            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                            user.setImageBitmap(bitmap);
                                        }

                                        //Log.i("My App", "Home Fragment - Username: " + user.getUsername() + " Name: " + user.getName() + " ProfImage:  "+ user.getImage()+ " Score: "+user.getScore());
                                        if(!users.contains(user.getUsername())){
                                            users.add(user);
                                            Log.i("My App", "Home Fragment - Users inside user snapshot : "+users);
                                        }

                                    }else{
                                        Log.i("My App", "Home Fragment - before Notify users list size:<" + users.size() + "> adapter size<" + postAdapter.getItemCount() + " >..... ");
                                        //postAdapter.notifyDataSetChanged();
                                        Log.i("My App", "Home Fragment - After Notify users list size: <" + users.size() + "> adapter size<" + postAdapter.getItemCount() + " >..... ");
                                    }

                                    //if(!postList2.isEmpty()) Log.i("My App", "Home Fragment - post list  : " + postList.get(0).toString());


                                    //recyclerViewState = recyclerViewPosts.getLayoutManager().onSaveInstanceState();
                                    postAdapter.notifyDataSetChanged();
                                   // recyclerViewPosts.suppressLayout(true); //working but remove likes and dislikes text ........
                                   // recyclerViewPosts.setNestedScrollingEnabled(false);

                                    recyclerViewPosts.setOnTouchListener(new View.OnTouchListener() {
                                        @Override
                                        public boolean onTouch(View v, MotionEvent event) {
                                         //   Toast.makeText(HomeActivity.this, "ScrollView Disabled", Toast.LENGTH_SHORT).show();
                                            recyclerViewPosts.suppressLayout(true);
                                            return true;
                                        }
                                    });

                                    Log.i("My App", "Home Fragment - After Notify:<" + postList.size() + "> adapter size<" + postAdapter.getItemCount() + " >..... ");

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });

                        }


                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });

        }


    }


}