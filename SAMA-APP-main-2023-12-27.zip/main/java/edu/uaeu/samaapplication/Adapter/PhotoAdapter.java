package edu.uaeu.samaapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import edu.uaeu.samaapplication.Post;
//back..
//import edu.uaeu.samaapplication.PostDetailActivity;
import edu.uaeu.samaapplication.PostDetailActivity;
import edu.uaeu.samaapplication.R;

import java.util.List;

public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.ViewHolder> {

    private Context mContext;
    private List<Post> mPosts;

    public PhotoAdapter(Context mContext, List<Post> mPosts) {
        this.mContext = mContext;
        this.mPosts = mPosts;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.i("My App", "Photo Adapter 1 ");
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.photo_item,parent,false);
        return new PhotoAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Log.i("My App", "Photo Adapter 2 ");
        Post post = mPosts.get(position);
        holder.postImage.setImageBitmap(post.getImageBitmap());
       // Picasso.get().load(post.getImage()).placeholder(R.mipmap.ic_launcher).into(holder.postImage);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS" , Context.MODE_PRIVATE).edit();
                editor.putString("postid" , post.getPostId());
                editor.putString("author" , post.getPublisher());

                editor.apply();
                mContext.startActivity(new Intent(view.getContext(), PostDetailActivity.class));
            }
        });


    }

    @Override
    public int getItemCount() {
        return this.mPosts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{


        public ImageView postImage;

        public ViewHolder(@NonNull View itemView) {

            super(itemView);
            postImage = itemView.findViewById(R.id.post_image);
            Log.i("My App", "Photo Adapter 3 ");

        }
    }

}


