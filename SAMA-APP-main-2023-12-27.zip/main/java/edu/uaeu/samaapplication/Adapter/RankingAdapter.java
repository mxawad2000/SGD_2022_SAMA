package edu.uaeu.samaapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import edu.uaeu.samaapplication.AccountManager;
//import edu.uaeu.samaapplication.AnotherProfileActivity;
//import edu.uaeu.samaapplication.PostDetailActivity;
//import edu.uaeu.samaapplication.ProfileActivity;
import edu.uaeu.samaapplication.R;
import edu.uaeu.samaapplication.User;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class RankingAdapter extends RecyclerView.Adapter<RankingAdapter.ViewHolder>{

private Context mContext;
private List<User> mUsers;
private boolean isFragment;

//private FirebaseUser firebaseUser;

public RankingAdapter(Context mContext, List<User> mUsers) {
        this.mContext = mContext;
        this.mUsers = mUsers;

        }

@NonNull
@Override
public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.rank_item , parent , false);
        return new RankingAdapter.ViewHolder(view);
        }

@Override
public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {


final User user = mUsers.get(position);
        //holder.btn_follow.setVisibility(View.VISIBLE);

        holder.name.setText(user.getName());
        holder.score.setText(user.getScore());
        holder.rank.setText(String.valueOf((mUsers.size() - position )));// index of list
    if (user.getImage().equals("default")) {
        //Log.i("My App", "From DB Image - User Adapter : " + AccountManager.getInstance().getProfileImg());
        holder.image_profile.setImageResource(R.drawable.imgpro);

    } else {
        holder.image_profile.setImageBitmap(user.getImageBitmap());

    }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {
        SharedPreferences.Editor editor =
                mContext.getSharedPreferences("PROFILE" , Context.MODE_PRIVATE).edit();
        editor.putString("username" , user.getUsername());
        editor.apply();



        //mContext.startActivity(new Intent(view.getContext(), AnotherProfileActivity.class));
        }
        });
        }




@Override
public int getItemCount() {
        return mUsers.size();
        }

public class ViewHolder extends RecyclerView.ViewHolder {

    public TextView name;
    public TextView score;
    public TextView rank;
    public CircleImageView image_profile;



    public ViewHolder(@NonNull View itemView) {
        super(itemView);

        name = itemView.findViewById(R.id.name_rank);
        score = itemView.findViewById(R.id.score_rank);
        rank = itemView.findViewById(R.id.rank);
        image_profile = itemView.findViewById(R.id.image_profile_rank);

    }
}


}
