package edu.uaeu.samaapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import edu.uaeu.samaapplication.AccountManager;
//import edu.uaeu.samaapplication.AnotherProfileActivity;
import edu.uaeu.samaapplication.AnotherProfileActivity;
import edu.uaeu.samaapplication.R;
import edu.uaeu.samaapplication.User;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder>{

private Context mContext;
private List<User> mUsers;
private boolean isFragment;

//private FirebaseUser firebaseUser;

public UserAdapter(Context mContext, List<User> mUsers, boolean isFragment) {
        this.mContext = mContext;
        this.mUsers = mUsers;
        this.isFragment = isFragment;
        }

@NonNull
@Override
public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.user_item , parent , false);
        return new UserAdapter.ViewHolder(view);
        }

@Override
public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {


final User user = mUsers.get(position);

        holder.username.setText("@"+user.getUsername());
        holder.fullname.setText(user.getName());
    if (user.getImage().equals("default")) {
        //Log.i("My App", "From DB Image - User Adapter : " + AccountManager.getInstance().getProfileImg());
        holder.image_profile.setImageResource(R.drawable.imgpro);

    } else {
        holder.image_profile.setImageBitmap(user.getImageBitmap());

    }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PROFILE" , Context.MODE_PRIVATE).edit();
                editor.putString("username" , user.getUsername());
                editor.apply();
                Intent intent = new Intent(mContext, AnotherProfileActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                mContext.startActivity(intent);

            }
        });


        }


@Override
public int getItemCount() {
        return mUsers.size();
        }

public class ViewHolder extends RecyclerView.ViewHolder {

    public TextView username;
    public TextView fullname;
    public CircleImageView image_profile;
   // public Button btn_follow;

    public ViewHolder(@NonNull View itemView) {
        super(itemView);

        username = itemView.findViewById(R.id.username);
        fullname = itemView.findViewById(R.id.fullname);
        image_profile = itemView.findViewById(R.id.image_profile);
       // btn_follow = itemView.findViewById(R.id.btn_follow);
    }
}

}

