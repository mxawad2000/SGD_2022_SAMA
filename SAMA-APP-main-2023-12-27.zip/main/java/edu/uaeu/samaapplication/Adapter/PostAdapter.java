package edu.uaeu.samaapplication.Adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import edu.uaeu.samaapplication.AccountManager;
//import edu.uaeu.samaapplication.AnotherProfileActivity;
import edu.uaeu.samaapplication.GoalManager;
//import edu.uaeu.samaapplication.HomeActivity;
import edu.uaeu.samaapplication.MainActivity;
import edu.uaeu.samaapplication.MyApp;
import edu.uaeu.samaapplication.Post;
//import edu.uaeu.samaapplication.PostDetailActivity;
//import edu.uaeu.samaapplication.ProfileActivity;
import edu.uaeu.samaapplication.R;
import edu.uaeu.samaapplication.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.List;

public class PostAdapter  extends  RecyclerView.Adapter<PostAdapter.Viewholder> {
    private Context mContext;
    private List<Post> mPost;
    private List<User> mUser;
    private AccountManager accountManager;


    public PostAdapter(Context mContext, List<Post> mPost , List<User> mUser) {
        this.mContext = mContext;
        this.mPost = mPost;
        this.mUser = mUser;
    }



    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Log.i("My App", "Post Adapter 0 ");
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post_item, parent, false);
        return new PostAdapter.Viewholder(view);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        holder.setIsRecyclable(false); //stay in the same position

        //Log.i("My App", "Post Adapter 1 ");
        accountManager = AccountManager.getInstance();
        Post post = mPost.get(position);
        //Log.i("My App", "Post Adapter - mUser size: " + mUser.size());
        //Log.i("My App", "Post Adapter - Position: " + position);

        holder.itemView.isSelected();
        for(int i = 0; i < mUser.size();i++) {
            if (mUser.get(i).getUsername().equals(post.getPublisher())) {
                if(mUser.get(i).getImage().equals("default")){
                    holder.imageProfile.setImageResource(R.drawable.imgpro);
                }else{
                    holder.imageProfile.setImageBitmap(mUser.get(i).getImageBitmap());
                }

            }
        }



        holder.description.setText(post.getDescription());
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();


        holder.username.setText(post.getPublisher());
        holder.author.setText(post.getPublisher());
        holder.description.setText(post.getDescription());
        holder.noOfLikes.setText(post.getLike());
        holder.noOfDislikes.setText(post.getDisLike());
        holder.post_image.setImageBitmap(post.getImageBitmap());
        holder.goalIcon.setImageResource(GoalManager.getInstance().getGoalLogo(post.getGoalId()));

        holder.link.setText(post.getLink());
        holder.link.setPaintFlags(holder.link.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        holder.link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(URLUtil.isValidUrl(post.getLink())){
                    Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(post.getLink()));
                    mContext.startActivity(browser);
                }else {
                  holder.link.setClickable(false);
                }
            }
        });

        //Log.i("My App","PostID 1:"+post.getPostId() );
        isLiked(post.getPostId(),holder.like, post.getGoalId());

        //Log.i("My App","Publisher2:"+post.getPublisher() );
        noOfLikes(post.getPostId(),holder.noOfLikes, post.getGoalId(), post.getPublisher());

        //Log.i("My App","PostID 1:"+post.getPostId() );
        isDisLiked(post.getPostId(),holder.dislike, post.getGoalId());

        //Log.i("My App","Publisher2:"+post.getPublisher() );
        noOfDisLikes(post.getPostId(),holder.noOfDislikes, post.getGoalId(), post.getPublisher());

        holder.more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(mContext,view );
                popupMenu.getMenuInflater().inflate(R.menu.option_user, popupMenu.getMenu());
                //Log.i("My App", "Past adapter - inside options");
                if(AccountManager.getInstance().getUserName().equals(post.getPublisher())) {
                    //Log.i("My App", "Past adapter - This user is the current user");
                    popupMenu.getMenu().findItem(R.id.option_delete).setVisible(true);
                    popupMenu.getMenu().findItem(R.id.option_report).setVisible(false);


                }else{
                    //Log.i("My App", "Past adapter - This user is not the current user");
                    popupMenu.getMenu().findItem(R.id.option_delete).setVisible(false);
                    popupMenu.getMenu().findItem(R.id.option_report).setVisible(true);
                }
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        //Log.i("My App", "Past adapter - inside menu pop up");

                            if(menuItem.getItemId() == R.id.option_delete){
                                //Log.i("My App","Current Activity: "+  mContext.getClass().getName());
                                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                                builder.setCancelable(true);
                                builder.setTitle("Confirm message");
                                builder.setMessage("Are you sure you want to Delete this post ?");
                                builder.setPositiveButton("Yes",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                String point;
                                                if(post.getPrivate()){
                                                     point = "0";
                                                }else{
                                                    point = post.getPoint();
                                                }
                                                AccountManager.getInstance().deletePost(post.getPublisher(), post.getPostId(),post.getGoalId(), point);
                                                //ProfileActivity pa = new ProfileActivity();
                                                //pa.deletePost(post.getPublisher(), post.getPostId(),post.getGoalId());
                                                Toast.makeText(mContext,"you deleted this post ", Toast.LENGTH_SHORT).show();
                                                //mContext.startActivity(new Intent(view.getContext(), HomeActivity.class));
                                              // ((Activity)mContext).finish();


                                                if (mContext.getClass().getName().contains("HomeActivity")) {
                                                    //mContext.startActivity(new Intent(view.getContext(), HomeActivity.class));

                                                }else{
                                                    ((Activity)mContext).finish();
                                                    //mContext.startActivity(new Intent(view.getContext(), ProfileActivity.class));
                                                }


                                            }
                                        });
                                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                    }
                                });

                                AlertDialog dialog = builder.create();
                                dialog.show();


                            }


                            if(menuItem.getItemId() == R.id.option_report){
                                Toast.makeText(mContext,"your report has been sent", Toast.LENGTH_SHORT).show();
                                FirebaseDatabase.getInstance().getReference().child("Goals").child(post.getGoalId()).child(post.getPostId()).child("Report")
                                        .child(AccountManager.getInstance().getUserName()).setValue(true);
                            }



                        return false;
                    }
                });
                popupMenu.show();
            }
        });

        holder.dislike.setOnClickListener(view -> {


            if(holder.dislike.getTag().equals("dislike")){

                if(post.getPrivate()){}else {
                    addNotification(post.getPostId(), post.getPublisher(), "Disliked your post.");


                    FirebaseDatabase.getInstance().getReference().child("Users")
                            .child(post.getPublisher())
                            .child("posts").child(post.getPostId())
                            .child("DisLikes")
                            .child(AccountManager.getInstance().getUserName()).setValue(true);


                    FirebaseDatabase.getInstance().getReference().child("Goals")
                            .child(post.getGoalId())
                            .child(post.getPostId())
                            .child("DisLikes")
                            .child(AccountManager.getInstance().getUserName()).setValue(true);

                    FirebaseDatabase.getInstance().getReference().child("Goals")
                            .child(post.getGoalId())
                            .child(post.getPostId())
                            .child("Likes")
                            .child(AccountManager.getInstance().getUserName()).removeValue();

                    FirebaseDatabase.getInstance().getReference().child("Users")
                            .child(post.getPublisher())
                            .child("posts").child(post.getPostId())
                            .child("Likes")
                            .child(AccountManager.getInstance().getUserName()).removeValue();

                    FirebaseDatabase.getInstance().getReference("Users/" + post.getPublisher() + "/Score").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            //Log.i("My App", "Score Value :" + snapshot.getValue().toString());
                            String Score = snapshot.getValue().toString();
                            int newscore = Integer.parseInt(Score) - 2;
                            FirebaseDatabase.getInstance().getReference("Users/" + post.getPublisher() + "/Score").setValue(newscore);


                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }

            }else{
                if(post.getPrivate()){}else {
                    FirebaseDatabase.getInstance().getReference().child("Users").child(post.getPublisher()).child("posts").child(post.getPostId()).child("Likes")
                            .child(AccountManager.getInstance().getUserName()).removeValue();

                    FirebaseDatabase.getInstance().getReference().child("Goals")
                            .child(post.getGoalId())
                            .child(post.getPostId())
                            .child("DisLikes")
                            .child(AccountManager.getInstance().getUserName()).removeValue();


                }


            }
           // refresh();

        });

    holder.like.setOnClickListener(view -> {
        if(holder.like.getTag().equals("like")){


            if(post.getPrivate()){}else{
                addNotification(post.getPostId(), post.getPublisher(),  "Liked your post.");
                FirebaseDatabase.getInstance().getReference().child("Users")
                        .child(post.getPublisher())
                        .child("posts").child(post.getPostId())
                        .child("Likes")
                        .child(AccountManager.getInstance().getUserName()).setValue(true);

                FirebaseDatabase.getInstance().getReference().child("Goals")
                        .child(post.getGoalId())
                        .child(post.getPostId())
                        .child("Likes")
                        .child(AccountManager.getInstance().getUserName()).setValue(true);

                FirebaseDatabase.getInstance().getReference().child("Goals")
                        .child(post.getGoalId())
                        .child(post.getPostId())
                        .child("DisLikes")
                        .child(AccountManager.getInstance().getUserName()).removeValue();

                FirebaseDatabase.getInstance().getReference().child("Users")
                        .child(post.getPublisher())
                        .child("posts").child(post.getPostId())
                        .child("DisLikes")
                        .child(AccountManager.getInstance().getUserName()).removeValue();


                FirebaseDatabase.getInstance().getReference("Users/"+post.getPublisher()+"/Score").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //Log.i("My App","Score Value :"+ snapshot.getValue().toString());
                        String Score = snapshot.getValue().toString();
                        int newscore = Integer.parseInt(Score ) + 2;
                        AccountManager.getInstance().setUserScore(newscore);
                        FirebaseDatabase.getInstance().getReference("Users/"+post.getPublisher()+"/Score").setValue(newscore);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }






        }else{
            if(post.getPrivate()){}else {
                FirebaseDatabase.getInstance().getReference().child("Users").child(post.getPublisher()).child("posts").child(post.getPostId()).child("Likes")
                        .child(AccountManager.getInstance().getUserName()).removeValue();

                FirebaseDatabase.getInstance().getReference().child("Goals")
                        .child(post.getGoalId())
                        .child(post.getPostId())
                        .child("Likes")
                        .child(AccountManager.getInstance().getUserName()).removeValue();

                FirebaseDatabase.getInstance().getReference("Users/" + post.getPublisher() + "/Score").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //Log.i("My App", "Score Value :" + snapshot.getValue().toString());
                        String Score = snapshot.getValue().toString();
                        int newscore = Integer.parseInt(Score) - 2;
                        FirebaseDatabase.getInstance().getReference("Users/" + post.getPublisher() + "/Score").setValue(newscore);


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
        }




    });

    holder.username.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            if(AccountManager.getInstance().getUserName().equals(post.getPublisher())){
                //mContext.startActivity(new Intent(view.getContext(), ProfileActivity.class));
            }else{
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PROFILE" , Context.MODE_PRIVATE).edit();
                editor.putString("username" , post.getPublisher()).apply();
                editor.apply();

                //mContext.startActivity(new Intent(view.getContext(), AnotherProfileActivity.class));
            }

        }
    });

    holder.imageProfile.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(AccountManager.getInstance().getUserName().equals(post.getPublisher())){
               // mContext.startActivity(new Intent(view.getContext(), ProfileActivity.class));
            }else{
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PROFILE" , Context.MODE_PRIVATE).edit();
                editor.putString("username" , post.getPublisher()).apply();
                editor.apply();

                //mContext.startActivity(new Intent(view.getContext(), AnotherProfileActivity.class));
            }
        }
    });

        holder.author.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(AccountManager.getInstance().getUserName().equals(post.getPublisher())){
                   // mContext.startActivity(new Intent(view.getContext(), ProfileActivity.class));
                }else{
                    SharedPreferences.Editor editor = mContext.getSharedPreferences("PROFILE" , Context.MODE_PRIVATE).edit();
                    editor.putString("username" , post.getPublisher()).apply();
                    editor.apply();

                    //mContext.startActivity(new Intent(view.getContext(), AnotherProfileActivity.class));
                }
            }
        });



    }



    private void addNotification(String postId, String publisher , String text) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("userid", AccountManager.getInstance().getUserName()); //
        map.put("text", text);
        map.put("postid", postId);
        map.put("ispost", true);

        FirebaseDatabase.getInstance().getReference("Users").child(publisher).child("Notifications").push().setValue(map);

    }

    private void noOfDisLikes(String postId, TextView noOfLikes, String goalId, String publisher) {
        // FirebaseDatabase.getInstance().getReference().child("Users").child(p).child("posts").child(postId).child("Likes").addValueEventListener(new ValueEventListener()
        FirebaseDatabase.getInstance().getReference().child("Goals").child(goalId).child(postId).child("DisLikes").addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                noOfLikes.setText(snapshot.getChildrenCount()+"");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void isDisLiked(String postId, ImageView dislike, String goalId) {
        FirebaseDatabase.getInstance().getReference().child("Goals").child(goalId).child(postId).child("DisLikes").addValueEventListener(new ValueEventListener()


        {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(AccountManager.getInstance().getUserName()).exists()){
                    dislike.setImageResource(R.drawable.ic_disliked);
                    dislike.setTag("disliked");
                }else{
                    dislike.setImageResource(R.drawable.ic_dislike);
                    dislike.setTag("dislike");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    @Override
    public int getItemCount() {
        return this.mPost.size();
    }


    public class Viewholder extends RecyclerView.ViewHolder {

        public ImageView imageProfile;
        public ImageView post_image;
        public ImageView like;
        public ImageView dislike;
        public ImageView more;
        public ImageView goalIcon;

        public TextView username;
        public TextView noOfLikes;
        public TextView noOfDislikes;
        public TextView author;
        public TextView description;
        public TextView link;


        public Viewholder(@NonNull View itemView) {
            super(itemView);
            imageProfile = itemView.findViewById(R.id.profile_image);
            post_image = itemView.findViewById(R.id.post_image);
            like = itemView.findViewById(R.id.like);
            dislike = itemView.findViewById(R.id.dislike);
            more = itemView.findViewById(R.id.more);
            goalIcon = itemView.findViewById(R.id.goal_img);


            username = itemView.findViewById(R.id.username);
            noOfLikes = itemView.findViewById(R.id.no_likes);
            noOfDislikes = itemView.findViewById(R.id.no_dislikes);
            author = itemView.findViewById(R.id.author);
            description = itemView.findViewById(R.id.description);
            link = itemView.findViewById(R.id.link_post);
        }
    }
    private void isLiked(String postId, ImageView imageView, String goalId){
        //FirebaseDatabase.getInstance().getReference().child("Users").child(p).child("posts").child(postId).child("Likes").addValueEventListener(new ValueEventListener()
                FirebaseDatabase.getInstance().getReference().child("Goals").child(goalId).child(postId).child("Likes").addValueEventListener(new ValueEventListener()


                {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(AccountManager.getInstance().getUserName()).exists()){
                    imageView.setImageResource(R.drawable.ic_liked);
                    imageView.setTag("liked");
                }else{
                    imageView.setImageResource(R.drawable.ic_like);
                    imageView.setTag("like");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void noOfLikes(String postId, TextView text, String goalId, String publisher){

      // FirebaseDatabase.getInstance().getReference().child("Users").child(p).child("posts").child(postId).child("Likes").addValueEventListener(new ValueEventListener()
                FirebaseDatabase.getInstance().getReference().child("Goals").child(goalId).child(postId).child("Likes").addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
             text.setText(snapshot.getChildrenCount()+"");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void refresh() {

        Intent intent = null;//new Intent(mContext, HomeActivity.class);
        ((Activity)mContext).overridePendingTransition(0, 0);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
       // ((Activity)mContext).finish();
        ((Activity)mContext).overridePendingTransition(0, 0);
        mContext.startActivity(intent) ;
       // this.notifyItemRangeChanged(0,this.getItemCount());




    }
}
