package edu.uaeu.samaapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import edu.uaeu.samaapplication.Goal;
import edu.uaeu.samaapplication.GoalInfoActivity;
import edu.uaeu.samaapplication.GoalManager;
import edu.uaeu.samaapplication.R;

public class AllGoalsAdapter extends RecyclerView.Adapter<AllGoalsAdapter.ViewHolder>{

    private Context mContext;
    private List<Goal> mGoals;


//private FirebaseUser firebaseUser;

    public AllGoalsAdapter(Context mContext, List<Goal> mGoals) {
        this.mContext = mContext;
        this.mGoals = mGoals;

    }

    @NonNull
    @Override
    public AllGoalsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.allgoal_item , parent , false);
        return new AllGoalsAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final AllGoalsAdapter.ViewHolder holder, int position) {

        final Goal goal = mGoals.get(position);
        //holder.btn_follow.setVisibility(View.VISIBLE);


        holder.allGoalItem.setImageResource(GoalManager.getInstance().getSqrGoalLogo(goal.getId()));

        //Log.i("My App", "Goal id "+ goal.getId()+" Goal Desc: "+goal.getDesc());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Log.i("My App", "On Click");
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS" , Context.MODE_PRIVATE).edit();
                editor.putString("goalid" , goal.getId());
                editor.apply();
                Intent intent = new Intent(view.getContext(), GoalInfoActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                mContext.startActivity(intent);
           }
        });






    }




    @Override
    public int getItemCount() {
        return mGoals.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        public ImageView allGoalItem;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            allGoalItem = itemView.findViewById(R.id.all_goal_item);

        }
    }
}
