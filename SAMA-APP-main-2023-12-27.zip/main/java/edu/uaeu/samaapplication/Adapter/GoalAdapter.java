package edu.uaeu.samaapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import edu.uaeu.samaapplication.Goal;
import edu.uaeu.samaapplication.GoalManager;
import edu.uaeu.samaapplication.GoalPosts;
//import edu.uaeu.samaapplication.PostDetailActivity;
import edu.uaeu.samaapplication.R;


import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class GoalAdapter extends RecyclerView.Adapter<GoalAdapter.ViewHolder>{

    private Context mContext;
    private List<Goal> mGoals;


    public GoalAdapter(Context mContext, List<Goal> mGoals) {
        this.mContext = mContext;
        this.mGoals = mGoals;

    }

    @NonNull
    @Override
    public GoalAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.goal_item , parent , false);
        return new GoalAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final GoalAdapter.ViewHolder holder, int position) {

        final Goal goal = mGoals.get(position);
        //holder.btn_follow.setVisibility(View.VISIBLE);
        holder.goal.setText(goal.getDesc());
        holder.icon.setImageResource(GoalManager.getInstance().getGoalLogo(goal.getId()));

        //Log.i("My App", "Goal id "+ goal.getId()+" Goal Desc: "+goal.getDesc());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS" , Context.MODE_PRIVATE).edit();
                    editor.putString("goalid" , goal.getId());
                    editor.apply();
                mContext.startActivity(new Intent(view.getContext(), GoalPosts.class));
            }
        });


    }




    @Override
    public int getItemCount() {
        return mGoals.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView goal;
        public CircleImageView icon;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            goal = itemView.findViewById(R.id.goal);
            icon = itemView.findViewById(R.id.goal_icon);
        }
    }


}
