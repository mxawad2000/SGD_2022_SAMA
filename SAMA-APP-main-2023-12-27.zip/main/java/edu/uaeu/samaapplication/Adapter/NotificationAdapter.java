package edu.uaeu.samaapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import edu.uaeu.samaapplication.AccountManager;
import edu.uaeu.samaapplication.Notification;
import edu.uaeu.samaapplication.Post;
//import edu.uaeu.samaapplication.PostDetailActivity;
//import edu.uaeu.samaapplication.ProfileActivity;
import edu.uaeu.samaapplication.R;
import edu.uaeu.samaapplication.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder>{

    private Context mContext;
    private List<Notification> mNotifications;

    public NotificationAdapter(Context mContext, List<Notification> mNotifications) {
        this.mContext = mContext;
        this.mNotifications = mNotifications;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.notification_item , parent , false);
        return new NotificationAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final Notification notification = mNotifications.get(position);
        holder.text.setText(notification.getText());
Log.i("My App", "Adapter - image profile: "+"Username of user: "+holder.username+" UserId: "+notification.getUserid());
        getUserInfo(holder.image_profile , holder.username , notification.getUserid());

        if (notification.isIspost()){
            holder.post_image.setVisibility(View.VISIBLE);
            getPostImage(holder.post_image , notification.getPostid(), AccountManager.getInstance().getUserName());
        } else {
            holder.post_image.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (notification.isIspost()){
                    SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS" , Context.MODE_PRIVATE).edit();
                    editor.putString("postid" , notification.getPostid());
                    editor.apply();

                    //mContext.startActivity(new Intent(v.getContext(), PostDetailActivity.class));
                } else {
                    SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS" , Context.MODE_PRIVATE).edit();
                    editor.putString("profileid" , notification.getUserid());
                    editor.apply();

                    //mContext.startActivity(new Intent(v.getContext(), ProfileActivity.class));
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return mNotifications.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public CircleImageView image_profile;
        public ImageView post_image;
        public TextView username;
        public TextView text;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image_profile = itemView.findViewById(R.id.image_profile_notification);
            post_image = itemView.findViewById(R.id.post_image);
            username = itemView.findViewById(R.id.username);
            text = itemView.findViewById(R.id.comment);
        }
    }

    private void getUserInfo(final CircleImageView imageView , final TextView username , String publisherid) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(publisherid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    //User user = dataSnapshot.getValue(User.class);// need to add using map this method is not working
                    Map<String, String> m = (Map<String, String>) dataSnapshot.getValue();
                    User user = (dataSnapshot.getValue(User.class));
                    //  Log.i("My App", "datasnapshot3333: " +post.toString());
                    user.setUsername(m.get("Username"));
                    user.setName(m.get("Name"));
                    user.setImage(m.get("ProfileImg"));
                    Log.i("My App", "Adapter - Username: "+m.get("Username") +" Name: "+m.get("Name")+" Profile Image: "+m.get("ProfileImg"));

                    if (user.getImage().equals("default")) {
                        Log.i("My App", "From DB Image - Notification Adapter user default image profile : " + user.getImage());
                        imageView.setImageResource(R.drawable.imgpro);

                    } else {
                        Log.i("My App", "From DB Image - Notification Adapter user has an image profile : " + user.getImage());
                        byte[] decodedString = Base64.decode(user.getImage(), Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        user.setImageBitmap(bitmap);
                        if (bitmap != null)
                        imageView.setImageBitmap(user.getImageBitmap());
                    }

                    username.setText(user.getUsername());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getPostImage (final ImageView imageView , String postid, String username) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(username).child("posts").child(postid);// need to change the path to Users > username > posts > postid
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    //Post post = dataSnapshot.getValue(Post.class);// we need to use hash map
                    //assert post != null;
                    //Picasso.get().load(post.getPostimage()).into(imageView); // we don't use picasso for images
                    //for(DataSnapshot s : dataSnapshot.getChildren()){
                    Map<String, String> m = (Map<String, String>) dataSnapshot.getValue();
                    Post post = (dataSnapshot.getValue(Post.class));
                    //  Log.i("My App", "datasnapshot3333: " +post.toString());
                    post.setAction(m.get("Action"));
                    post.setGoal(m.get("Goal"));
                    post.setDescription(m.get("Description"));
                    post.setLike(m.get("Like"));
                    post.setGoalId(m.get("Goal ID"));
                    post.setPrivate(Boolean.valueOf(m.get("Private")));
                    post.setPoint(m.get("Point"));
                    post.setPublisher(m.get("Publisher"));
                    post.setDisLike(m.get("Dislike"));
                    post.setPostId(m.get("Post ID"));
                    post.setLink(m.get("Link"));

                    byte[] decodedString = Base64.decode(post.getImage(), Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    post.setImageBitmap(decodedByte);
                    imageView.setImageBitmap(post.getImageBitmap());

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
