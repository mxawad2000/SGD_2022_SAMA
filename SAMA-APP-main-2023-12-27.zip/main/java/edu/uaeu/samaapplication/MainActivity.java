package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Camera;
import android.graphics.Matrix;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.ByteArrayOutputStream;
import java.io.FileDescriptor;
import java.io.IOException;
import java.util.Date;
import java.time.Clock;
import java.util.HashMap;
import edu.uaeu.samaapplication.util.GenUtil;

public class MainActivity extends AppCompatActivity {
    ArrayAdapter<CharSequence>adapterAction;
    private ImageView image;
    private ImageView close;
    private EditText description;
    private EditText link;
    private RadioButton is_private;
    private RadioButton is_public;
    private Button share;
    private Spinner spinnerGoals;
    private Spinner spinnerActions;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private Post np;
    private String imageEncoded;
    private String goalid;
    private String actionid;
    private String point;
    private String like = "0";
    private String dislike = "0";
    private Post post = new Post();
    private String publisher = AccountManager.getInstance().getUserName();
    private ProgressBar simpleProgressBar ;

    private  Uri selectedImage;
    private Bitmap bitmap;

   private static final int CAMERA_REQUEST = 1888;
   private static final int MY_CAMERA_PERMISSION_CODE = 100;

  // private SharedPreferences sharedPref = getSharedPreferences("com.example.FirebaseDemo.PREFERENCE_FILE_KEY", Context.MODE_PRIVATE );


    private Bitmap uriToBitmap(Uri selectedFileUri) {
        try {
            ParcelFileDescriptor parcelFileDescriptor = getContentResolver().openFileDescriptor(selectedFileUri, "r");
            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
            Bitmap image = BitmapFactory.decodeFileDescriptor(fileDescriptor);

            parcelFileDescriptor.close();
            return image;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  null;
    }


    private void encodeBitmapAndSaveToFirebase(Bitmap photo) {

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        photo.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        imageEncoded = Base64.encodeToString(byteArray, Base64.DEFAULT);

    }
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 0) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap photo = (Bitmap)data.getExtras().get("data");
        //image.setImageBitmap(photo);
        //Bitmap photo;
        if(resultCode != RESULT_CANCELED) {
            switch (requestCode) {
                case 0:
                    if (resultCode == RESULT_OK && data != null) {
                         photo = (Bitmap) data.getExtras().get("data");

                        Matrix matrix = new Matrix();

                        matrix.postRotate(0); //

                        Bitmap scaledBitmap = Bitmap.createScaledBitmap(photo, photo.getWidth(), photo.getHeight(), true);

                        Bitmap rotatedBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0, scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix, true);

                        image.setImageBitmap(rotatedBitmap);
                        photo = getResizedBitmap(rotatedBitmap, 500);// 1000 is too large it will start lagging
                    }

                    break;
                case 1:
                    if (resultCode == RESULT_OK && data != null) {
                        selectedImage = data.getData();
                        //Log.i("My App","Selected Iamge: "+selectedImage);
                        //imageView.setImageURI(image_uri);
                        bitmap = uriToBitmap(selectedImage);// it works but don;t save to database + takes a lot of time to put the image in the image view
                        // bitmap = StringToBitMap(String.valueOf(selectedImage));// does not work


                        Matrix matrix = new Matrix();

                        matrix.postRotate(0); //

                        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth(), bitmap.getHeight(), true);

                        Bitmap rotatedBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0, scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix, true);

                        image.setImageBitmap(rotatedBitmap);
                        photo = getResizedBitmap(rotatedBitmap, 500);// 1000 is too large it will start lagging
                        //encodeBitmapAndSaveToFirebase(photo);

                    }
                    break;
            }
        }
    encodeBitmapAndSaveToFirebase(photo);
    }


    private void selectImage(Context context) {
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","No Image","Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Choose your profile picture");
        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (options[item].equals("Take Photo")) {
                    Intent takePicture = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 0);

                } else if (options[item].equals("Choose from Gallery")) {
                    Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhoto , 1);

                } else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                    finish();
                }else if(options[item].equals("No Image")){
                    //do nothing...
                }
            }
        });
        builder.show();
    }



    @RequiresApi(api = Build.VERSION_CODES.M)


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        spinnerGoals=findViewById(R.id.goals);
        spinnerActions=findViewById(R.id.actions);
        description = findViewById(R.id.description);
        link = findViewById(R.id.link);
        is_private = findViewById(R.id.radio_private);
        is_public = findViewById(R.id.radio_public);
        share = findViewById(R.id.share);
        image = findViewById(R.id.image_added);
        close = findViewById(R.id.close_add);
        simpleProgressBar = (ProgressBar) findViewById(R.id.simpleProgressBar_main);

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //np.setImage(image);

        selectImage(this);

        is_public.setChecked(true);

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
        }



        // below line is used to get the
        // instance of our Firebase database.
        firebaseDatabase = FirebaseDatabase.getInstance();
        // below line is used to get reference for our database.
        databaseReference = firebaseDatabase.getReference("Users");
        //Log.i("myApp",(databaseReference == null) +"");


        ArrayAdapter<CharSequence>adapterGoal=ArrayAdapter.createFromResource(this, R.array.Goals, android.R.layout.simple_spinner_item);
        adapterGoal.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerGoals.setAdapter(adapterGoal);
        spinnerGoals.setSelection(0);
        adapterAction=ArrayAdapter.createFromResource(MainActivity.this,R.array.Goal1, android.R.layout.simple_spinner_item);
        adapterAction.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerActions.setAdapter(adapterAction);

        spinnerGoals.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //Log.i("My App", "here we are, selected item is:" + i);
                int resourceId = GenUtil.getResourceByName("Goal" + (i+1) , "array");
                adapterAction=ArrayAdapter.createFromResource(MainActivity.this, resourceId, android.R.layout.simple_spinner_item);
                goalid="G" + (i+1);
                adapterAction.setDropDownViewResource(android.R.layout.simple_spinner_item);
                spinnerActions.setAdapter(adapterAction);
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        share.setClickable(true);
        db.collection("Goals").get().addOnCompleteListener(task -> {
                        share.setOnClickListener(view -> {
                            simpleProgressBar.setVisibility(View.VISIBLE);
                            share.setClickable(false);
                            String spin_goal = spinnerGoals.getSelectedItem().toString();
                            String spin_action = spinnerActions.getSelectedItem().toString();
                            String des = description.getText().toString();
                            String lin = link.getText().toString();
                            boolean isPrivate = false;
                            if (is_private.isChecked()) {
                                isPrivate = true;
                            }
                            //Log.i("My App","start firestore");
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        //Log.d("My App", document.getId() + " => " + document.getData());
                                        if (document.getData().containsKey(spin_action)) {
                                            //Log.i("My App",spinnerActions.getSelectedItem().toString());
                                            point = (String) document.get(spinnerActions.getSelectedItem().toString());
                                           // Log.i("My App","Selected action is:" + point);
                                        }
                                    }
                                    if(point == null) point = "0";
                                } else {
                                    Log.w("My App", "Error getting documents.", task.getException());
                                }

                            addDatatoFirebase(imageEncoded, spin_goal, spin_action, des, lin, isPrivate, point);

                            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);

                            });
        });

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_add);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if(id == R.id.nav_home) {
                    startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if(id == R.id.nav_search) {
                    startActivity(new Intent(getApplicationContext(), SearchActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if(id == R.id.nav_add) {

                    return true;
                }
                if(id == R.id.nav_heart) {
                    startActivity(new Intent(getApplicationContext(), NotificationActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if(id == R.id.nav_profile) {
                    startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                }

                return false;
            }
        });


    }

                    private void addDatatoFirebase(String photo, String goal, String action, String description, String link, Boolean isPrivate, String point) {
                        Date today = new Date();
                        String user = AccountManager.getInstance().getUserName();
                        String pid = user + today.getTime();

                        HashMap<String, String> map = new HashMap<>();
                        map.put("Image", photo);
                        map.put("Goal", goal);
                        map.put("Goal ID", goalid);
                        map.put("Action", action);
                        map.put("Description", description);
                        map.put("Link", link);
                        map.put("Private", isPrivate.toString());
                        map.put("Point", point);
                        //map.put("Like", like);
                        //map.put("Dislike", dislike);
                        map.put("Publisher", publisher);
                        map.put("Post ID", pid);
                        //Log.i("My App", "Value of Account manager: "+ AccountManager.getInstance().getScore() );
//String image, String goal, String goalId, String action, String descripton, String link, Boolean isPrivate, String point, String like, String disLike)
                        //post = new Post(photo,goal,goalid,action,description,link,isPrivate,point,like,dislike,publisher);

                        int newScore=0;
                        //Log.i("My App", "Score: "+ AccountManager.getInstance().getScore());
                        if(point !=null)
                            Log.i("My App", "Point + Score: "+ (AccountManager.getInstance().getScore() + Integer.parseInt(point)));

                        if(isPrivate){
                            newScore = (AccountManager.getInstance().getScore() + 0);
                        }else{
                            //Log.i("My App","point is null?" + (point == null));
                            newScore = (AccountManager.getInstance().getScore() + Integer.parseInt(point));
                        }

                        //Log.i("My App", "Value of Score: "+ newScore);

                        AccountManager.getInstance().setUserScore(newScore);

                       // Log.i("My App", "Value of Score2: "+ AccountManager.getInstance().getScore());

                        firebaseDatabase.getReference("Users/"+user+"/Score").setValue(newScore);
                        firebaseDatabase.getReference("Users/"+user+"/posts/" + pid).setValue(map);
                        firebaseDatabase.getReference("Goals/"+goalid+"/" + pid).setValue(map);

                        // we are use add value event listener method

                    }


                }


