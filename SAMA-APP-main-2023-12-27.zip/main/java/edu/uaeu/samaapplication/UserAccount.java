package edu.uaeu.samaapplication;

public class UserAccount {
    public String name;
    public String userName;
    public String password;
    public int score;
    public String profileImg;

    @Override
    public String toString() {
        return "UserAccount{" +
                "name='" + name + '\'' +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", score=" + score +
                ", profileImg='" + profileImg + '\'' +
                '}';
    }
}
