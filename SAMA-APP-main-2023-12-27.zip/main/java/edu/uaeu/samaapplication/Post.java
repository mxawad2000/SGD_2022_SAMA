package edu.uaeu.samaapplication;

import android.graphics.Bitmap;
import android.media.Image;

import java.sql.Date;
import java.sql.Time;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class Post {
    private String Image;
    private String Goal;
    private String GoalId;
    private String Action;
    private String Description;
    private String Link;
    private String Private;
    private String Point;
    private String Like;
    private String DisLike;
    private String publisher;
    private Bitmap imageBitmap;
    private String PostId;



    public Post(String image, String goal, String goalId, String action, String description, String link, Boolean isPrivate, String point, String like, String disLike, String publisher, String PostId) {
        this.Image = image;
        this.Goal = goal;
        this.GoalId = goalId;
        this.Action = action;
        this.Description = description;
        this.Link = link;
        this.Private = isPrivate +"";
        this.Point = point;
        this.Like = like;
        this.DisLike = disLike;
        this.publisher = publisher;
        this.PostId = PostId;
    }
    public Post(){

    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        this.Image = image;
    }
    public void setImageBitmap(Bitmap image) {
        this.imageBitmap = image;
    }
    public Bitmap getImageBitmap() {
        return imageBitmap;
    }

    public String getGoal() {
        return Goal;
    }

    public void setGoal(String goal) {
        Goal = goal;
    }

    public String getGoalId() {
        return GoalId;
    }

    public void setGoalId(String goalId) {
        this.GoalId = goalId;
    }

    public String getAction() {
        return Action;
    }

    public void setAction(String action) {
        this.Action = action;
    }


    public String getLink() {
        return Link;
    }

    public void setLink(String link) {
        this.Link = link;
    }

    public Boolean getPrivate() {
        return Boolean.parseBoolean(Private);
    }

    public void setPrivate(Boolean aPrivate) {
        Private = aPrivate +"";
    }

    public String getPoint() {
        return Point;
    }

    public void setPoint(String point) {
        this.Point = point;
    }

    public String getLike() {
        return Like;
    }

    public void setLike(String like) {
        this.Like = like;
    }

    public String getDisLike() {
        return DisLike;
    }

    public void setDisLike(String disLike) {
        this.DisLike = disLike;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }



    public String getPostId() {
        return PostId;
    }

    public void setPostId(String postId) {
        PostId = postId;
    }

    public Post getPost(){
        Post p = new Post( Image,  Goal,  GoalId,  Action,  Description,  Link,  Boolean.parseBoolean(Private),  Point,  Like,  DisLike, publisher, PostId);
        return p;
    }
    public void setPost(Post p){
         p = new Post( Image,  Goal,  GoalId,  Action,  Description,  Link,  Boolean.parseBoolean(Private),  Point,  Like,  DisLike, publisher, PostId);
    }


    public String toString2() {
        return "Post{" +
                "image='" + imageBitmap + '\'' +
                ", Goal='" + Goal + '\'' +
                ", goalId='" + GoalId + '\'' +
                ", action='" + Action + '\'' +
                ", description='" + Description + '\'' +
                ", link='" + Link + '\'' +
                ", isPrivate=" + Private +
                ", point='" + Point + '\'' +
                ", like='" + Like + '\'' +
                ", disLike='" + DisLike + '\'' +
                ", publisher='" + publisher + '\'' +
                '}';
    }

    public String toString() {
        return "Post id:" + this.PostId;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Post)) return false;
        Post post = (Post) o;
        return Objects.equals(PostId, post.PostId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(PostId);
    }
}
