package edu.uaeu.samaapplication;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class AccountManager {

    private Context mContext;
    private static AccountManager instance = new AccountManager();
    private String nameSharedPrefID = "MyTerraApplication.CIT.AE";
    private UserAccount currentUser;
    SharedPreferences sharedPref ;
    private int newScore;
    private Post post ;
    private User user1;
    private String Score="0" ;
    private String Point;
    public static AccountManager getInstance(){ return instance;}
    private AccountManager (){
        sharedPref = MyApp.getAppContext().getSharedPreferences(nameSharedPrefID, Context.MODE_PRIVATE );
        currentUser = getAccount();
    }
    private UserAccount getAccount(){
        UserAccount user = new UserAccount();
        String username = sharedPref.getString("username","");
        String pw = sharedPref.getString("password","");
        String name = sharedPref.getString("name","");
        String score = sharedPref.getString("score","");
        //sharedPref.getStringSet()
        String profileImg = sharedPref.getString("profileImg","");
        if(username == "") return null;
        user.userName = username;
        user.password = pw;
        user.name=name;
        user.profileImg=profileImg;
        user.score = Integer.parseInt(score);
        return user;
    }
    public void setUserAccount(String userName, String pw, String name, String score, String profileImg){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("username",userName);
        editor.putString("password",pw); //hash it..
        editor.putString("name",name);
        editor.putString("score",score);
        editor.putString("profileImg",profileImg);
        editor.commit();
        this.currentUser = new UserAccount();
        this.currentUser.name = name;
        this.currentUser.userName = userName;
        this.currentUser.score = Integer.parseInt(score);
        this.currentUser.password = pw;
        this.currentUser.profileImg=profileImg;
    }
    public String getUserName(){
        if(currentUser!=null) return currentUser.userName;
        return null;
    }
    public String getName(){
        if(currentUser!=null) return currentUser.name;
        return null;
    }
    public int getScore(){
        if(currentUser!=null) return currentUser.score;
        return 10;
    }

    public String getProfileImg(){
        if(currentUser!=null) return currentUser.profileImg;
        return "KKKK";
    }

    public String getPassword(){
        if(currentUser!=null) return currentUser.password;
        return "KKKK";
    }

    public void setProfileImg(String s){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("profileImg", s);
        editor.commit();
        this.currentUser.profileImg = s;
    }
    public void setName(String s){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("name", s);
        editor.commit();
        this.currentUser.name = s;
    }

    public void setUsername(String s){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("username", s);
        editor.commit();
        this.currentUser.userName = s;
    }

    public void setPassword(String s){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("password", s);
        editor.commit();
        this.currentUser.password = s;
    }


    public void setUserScore(int score){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("score", String.valueOf(score));
        editor.commit();
        this.currentUser.score = score;
    }

    public void logOut(){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.remove("username");
        /*
        editor.putString("password",pw); //hash it..
        editor.putString("name",name);
        editor.putString("score",score);
        editor.putString("profileImg",profileImg);

         */
        editor.commit();
        this.currentUser = null;
    }
 //public void getScore(String user, String postId )
    public void deletePost(String user, String postId, String goalId, String point){

      int userScore = AccountManager.getInstance().getScore();
      newScore = userScore - Integer.parseInt(point);
      //Log.i("My App", "<Score: "+userScore +", Point: "+point+" ,New Score: "+ newScore+" >");
      FirebaseDatabase.getInstance().getReference("Users").child(user).child("Score").setValue(newScore);
      AccountManager.getInstance().setUserScore(newScore);


        FirebaseDatabase.getInstance().getReference("Users").child(user).child("posts").child(postId).removeValue();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child(user);
        Query applesQuery = ref.child("Notifications").orderByChild("postid").equalTo(postId);


        applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    for (DataSnapshot post : dataSnapshot.getChildren()) {
                        //Log.i("My App", "Notification is being removed");
                        post.getRef().removeValue();
                        //Log.i("My App", "Notification has been removed");
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.i("My App", "onCancelled", databaseError.toException());
            }
        });

        FirebaseDatabase.getInstance().getReference("Goals").child(goalId).child(postId).removeValue();

    }

    void setScore(String user){
        //Log.i("My App", "Score:"+ Score+" Point: "+ Point+" nothing ");
        //newScore = (Integer.parseInt(Score) - Integer.parseInt(Point) );
        newScore = 100 - Integer.parseInt(Point) ;
        FirebaseDatabase.getInstance().getReference("Users").child(user).child("Score").setValue(newScore);
        //Log.i("My App","new score:" + newScore);
        AccountManager.getInstance().setUserScore(newScore);
    }
    public UserAccount getCurrentUser(){
        return this.currentUser;
    }
}
