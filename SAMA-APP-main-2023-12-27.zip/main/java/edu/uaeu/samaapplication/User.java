package edu.uaeu.samaapplication;

import android.graphics.Bitmap;

public class User {

    private String username;
    private String name;
    private String image;
    private Bitmap imageBitmap;
    private String score;


    public User() {
    }

    public User(String username, String name, String image, String score) {
        this.username = username;
        this.name = name;
        this.image = image;
        this.score = score;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    public void setImageBitmap(Bitmap image) {
        this.imageBitmap = image;
    }
    public Bitmap getImageBitmap() {
        return imageBitmap;
    }
}
