package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import edu.uaeu.samaapplication.Adapter.PhotoAdapter;

public class AnotherProfileActivity extends AppCompatActivity {

    private PhotoAdapter photoAdapter;
    private List<Post> myPhotolist;

    private CircleImageView imageProfile;
    private TextView posts;
    private TextView score;
    private TextView username;
    private TextView name;
    private  ImageView back;

    private RecyclerView myPictures;

    String searched_username;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_another_profile);


        Log.i("My App", "Another Profile - Activity 1" );

        SharedPreferences prefs = this.getSharedPreferences("PROFILE" , Context.MODE_PRIVATE);
        searched_username = prefs.getString("username" , "none");



        back = findViewById(R.id.another_profile_arrow);
        imageProfile = findViewById(R.id.another_profile_image_profile);
        posts = findViewById(R.id.another_profile_posts);
        score = findViewById(R.id.another_profile_score);
        username = findViewById(R.id.another_profile_username);
        name = findViewById(R.id.another_profile_name);




        myPictures =findViewById(R.id.another_profile_recycler_view);
        myPictures.setHasFixedSize(true);
        myPictures.setLayoutManager(new GridLayoutManager(this, 3));
        myPhotolist = new ArrayList<>();
        photoAdapter = new PhotoAdapter(this,myPhotolist);
        myPictures.setAdapter(photoAdapter);

        Log.i("My App", "Another Profile - Activity 2" );
        usernfo();
        Log.i("My App", "Another Profile - Activity 3" );
        userProfileImage();
        getPostCount();
        getScore();
        Log.i("My App", "Another Profile - Activity 4" );
        myPhotos();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("My App", "Another Profile - Activity return back : In" );
                finish();
                Log.i("My App", "Another Profile - Activity 5 Finish....." );
            }
        });



    }
    private void myPhotos() { // we need to add here a parameter to see if the user is he owner of the account he can view the private images and vice versa
        Log.i("My App", "Profile Fragment 5 : myPhotos method In" );
        FirebaseDatabase.getInstance().getReference().child("Users").child(searched_username).child("posts").addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    Log.i("My App", "Another Profile - Activity 6 : Snapshot");
                    Log.i("My App", "Another Profile - Activity snapshot: " + snapshot.getValue());

                    for (DataSnapshot s : snapshot.getChildren()) {
                        Log.i("My App", "Another Profile - Activity 7 : Snapshot s ");
                        Log.i("My App", "Another Profile - Activity 8 data snapshot ALL: " + s.getValue());
                        Map<String, String> m = (Map<String, String>) s.getValue();
                        Post post = (snapshot.getValue(Post.class));
                        //  Log.i("My App", "datasnapshot3333: " +post.toString());
                        post.setAction(m.get("Action"));
                        post.setGoal(m.get("Goal"));
                        post.setDescription(m.get("Description"));
                        post.setLike(m.get("Like"));
                        post.setGoalId(m.get("Goal ID"));
                        post.setPrivate(Boolean.valueOf(m.get("Private")));
                        post.setPoint(m.get("Point"));
                        post.setPublisher(m.get("Publisher"));
                        post.setDisLike(m.get("Dislike"));
                        post.setPostId(m.get("Post ID"));
                        post.setImage(m.get("Image"));
                        post.setLink(m.get("Link"));
                        //Log.i("My App", "Another Profile - Activity IMAGE: " + post.getImage());
                        if(post.getImage()!=null) {
                            byte[] decodedString = Base64.decode(post.getImage(), Base64.DEFAULT);
                            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                            post.setImageBitmap(decodedByte);
                            //Log.i("My App", "Another Profile - Activity IMAGE: " + post.getImageBitmap());
                        }else{
                            Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.img_not_available);
                            post.setImageBitmap(largeIcon);
                        }
                        if (!post.getPrivate()) {
                            Log.i("My App", "Another Profile - Activity 9 : getPublisher ");
                            if(myPhotolist.contains(post)) continue;
                            myPhotolist.add(post);
                        }
                    }
                    Log.i("My App", "Another Profile - Activity post list  : " + myPhotolist.get(0).toString());
                    Collections.reverse(myPhotolist);
                    photoAdapter.notifyDataSetChanged();
                    Log.i("My App", "Another Profile - Activity After Notify:<" + myPhotolist.size() + "> adapter size<" + photoAdapter.getItemCount() + " >..... ");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void userProfileImage() {
        FirebaseDatabase.getInstance().getReference().child("Users").child(searched_username).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                User user = snapshot.getValue(User.class);
                Map<String, String> m = (Map<String, String>) snapshot.getValue();
                if ( m.get("ProfileImg").equals("default")) {
                    Log.i("My App","Another Profile - Activity From DB Image  : " + m.get("ProfileImg"));

                    Picasso.get().load( R.drawable.imgpro).into(imageProfile);
                } else {
                    Log.i("My App","Another Profile - Activity User has a ProfileImg: " + m.get("ProfileImg"));


                    byte[] decodedString = Base64.decode(m.get("ProfileImg"), Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    if (bitmap != null)


                        imageProfile.setImageBitmap(bitmap);

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void getScore() {
        FirebaseDatabase.getInstance().getReference().child("Users").child(searched_username).child("Score").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    score.setText(snapshot.getValue().toString());
                }else{
                    score.setText("DNE");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void getPostCount() {
        FirebaseDatabase.getInstance().getReference().child("Users").child(searched_username).child("posts").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    posts.setText("" + snapshot.getChildrenCount());
                }else{
                    posts.setText("0");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    private void usernfo() {
        FirebaseDatabase.getInstance().getReference().child("Users").child(searched_username).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                Log.i("My App", "Another Profile - Activity UserInfo: IN ");
                if(snapshot.exists()) {
                    Map<String, String> m = (Map<String, String>) snapshot.getValue();
                    User user = (snapshot.getValue(User.class));
                    Log.i("My App", "Another Profile - Activity Username: "+m.get("Username")+" Name: "+m.get("Name"));
                    user.setUsername(m.get("Username"));
                    user.setName(m.get("Name"));

                    // User user = snapshot.getValue(User.class);
                    username.setText("@"+user.getUsername());
                    name.setText(user.getName());

                }else{
                    Log.i("My App","Another Profile - Activity Snapshot is Empty>>>>");
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


}