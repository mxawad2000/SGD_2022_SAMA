package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    private EditText username;
    private EditText password;
    private ImageView back;
    private ImageView eye;
    private Button login;
    private TextView registerUser;
    DatabaseReference databaseReference;
    private String profileImg = "default";
    private ProgressBar simpleProgressBar ;

    // private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);
        registerUser = findViewById(R.id.register_user);
        back = findViewById(R.id.backArrow_login);
        eye = findViewById(R.id.eye_login);// change
        simpleProgressBar = (ProgressBar) findViewById(R.id.simpleProgressBar_login);



        eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(password.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance())){
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }else{
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        registerUser.setOnClickListener(view -> startActivity(new Intent(LoginActivity.this, ResetPasswordActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)));

        login.setOnClickListener(view -> {

            Log.i("My App" , "login button clicked...");
            String entered_username =  username.getText().toString();
            String entered_password = password.getText().toString();
            SecurityManager.HashMethod hashMethod = SecurityManager.getAppropriateHash();
            String hashPass = SecurityManager.getHashedPassword( hashMethod, entered_password );

            if(TextUtils.isEmpty(entered_username)||TextUtils.isEmpty(entered_password)){
                Toast.makeText(LoginActivity.this, "Empty Credentials!",Toast.LENGTH_SHORT).show();

            }else{
                Log.i("My App", "username and password not empty");
                databaseReference = FirebaseDatabase.getInstance().getReference("Users");
                Query userCheck = databaseReference.orderByChild("Username").equalTo(entered_username);
                Log.i("My App", String.valueOf(userCheck));
                //Here...
                userCheck.addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Log.i("My App", "in");
                        if(snapshot.exists()){
                            Log.i("My App", "snapshot exists!");
                            String passwordFromDatabase = snapshot.child(entered_username).child("Password").getValue(String.class);
                            if (passwordFromDatabase.equals(hashPass)) {
                                simpleProgressBar.setVisibility(View.VISIBLE);
                               // Log.i("My App", "Password from DB");
                                String name = snapshot.child(entered_username).child("Name").getValue(String.class);
                                String score = snapshot.child(entered_username).child("Score").getValue().toString();
                                Log.i("My App", "Score from Database "+ score);
                                //Log.i("My App" , name);
                                Toast.makeText(LoginActivity.this, "Correct Information ",Toast.LENGTH_SHORT).show();
                                AccountManager.getInstance().setUserAccount(entered_username,hashPass,name,score,profileImg);
                                Log.i("My App", "Intent...");
                                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                            } else {
                                Toast.makeText(LoginActivity.this, "Password Wrong ",Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(LoginActivity.this, "Data not Exists ",Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });

    }





}