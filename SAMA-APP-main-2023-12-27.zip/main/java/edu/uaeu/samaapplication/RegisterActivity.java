package edu.uaeu.samaapplication;
//puplic facing name for teh project: project-113485699390
//support email: mamoun.uaeu@gmail.com


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {
    private EditText username;
    private EditText name;
    private EditText email;
    private EditText phone;
    private EditText password;
    private ImageView back;
    private ImageView eye;
    private Button register;
    private TextView loginUser;
    private String profileImg ="default";
    private ProgressBar simpleProgressBar ;
    FirebaseDatabase firebasedatabase;
    DatabaseReference databaseReference;
    Post post;
    private String [] intList = new String [17];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = findViewById(R.id.username);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        password = findViewById(R.id.password);
        register = findViewById(R.id.register);
        loginUser = findViewById(R.id.login_user);
        back = findViewById(R.id.backArrow_register);
        eye = findViewById(R.id.eye_register);// change
        simpleProgressBar = (ProgressBar) findViewById(R.id.simpleProgressBar_register);



        eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(password.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance())){
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }else{
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        firebasedatabase = FirebaseDatabase.getInstance();
        loginUser.setOnClickListener(view -> startActivity(new Intent(RegisterActivity.this, LoginActivity.class)));
       // register.setClickable(true);
        register.setOnClickListener(v -> {

           // register.setClickable(false);
            Log.i("My App", "Here");
            String txtUsername = username.getText().toString();
            String txtName = name.getText().toString();
            String txtEmail = email.getText().toString();
            String txtPhone = phone.getText().toString();
            String txtPassword = password.getText().toString();
            String txtScore = "0";
            String txtInterest = "";

            FirebaseDatabase.getInstance().getReference("Users").orderByChild("Phone").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()){
                        phone.setError("Phone already used ");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

            ArrayList<String> username_list = new ArrayList<>();
            ArrayList<String> phone_list = new ArrayList<>();
            String strUsername = username.getText().toString().trim();
            String strPhone = phone.getText().toString().trim();
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users/");
            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Log.i("My App", "Here!!!");
                    Log.i("My App","datasnapshot: "+snapshot.getKey());
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        String users_from_database = (String) ds.child("Username").getValue();
                        String phone_from_database = (String) ds.child("Phone").getValue();

                        username_list.add(users_from_database);
                        phone_list.add(phone_from_database);
                        StringBuilder stringBuilder = new StringBuilder();
                        for (String s : username_list) {
                            stringBuilder.append(s + "\n");
                        }
                    }

                    Log.i("My App", "Here2");
                        //  Log.d("ZI", stringBuilder.toString());
                            if (TextUtils.isEmpty(txtUsername) || TextUtils.isEmpty(txtName) || TextUtils.isEmpty(txtEmail) || TextUtils.isEmpty(txtPhone) || TextUtils.isEmpty(txtPassword)) {
                                Log.i("My App", "Here3");
                                Toast.makeText(RegisterActivity.this, "All fields are required!", Toast.LENGTH_SHORT).show();
                                //pd.dismiss();
                            }
                            else if (txtPassword.length() < 6) {
                                Toast.makeText(RegisterActivity.this, "Password must be over 6 characters.", Toast.LENGTH_SHORT).show();
                                //  pd.dismiss();
                            }

                            else if(username_list.contains(strUsername)) {
                                Log.i("My App","inside if");
                            username.setError("Username Exist");
                           // pd.dismiss();
                          } else if(phone_list.contains(strPhone)){
                                Log.i("My App","check phone");
                                phone.setError("Phone already used ");

                            } else {
                                simpleProgressBar.setVisibility(View.VISIBLE);
                                SecurityManager.HashMethod hashMethod = SecurityManager.getAppropriateHash();
                                String hashPass = SecurityManager.getHashedPassword( hashMethod, txtPassword );
                            registerUser(txtUsername, txtName, txtEmail, txtPhone, hashPass,txtScore,txtInterest,profileImg);
                                Log.i("My App","registered");
                        }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.d("ZI", "Failed");
                }
            });




        });
    }
    private void registerUser(String username, String name, String email,String phone, String password,String score,String interests,String profile){

        HashMap<String,Object> map = new HashMap<>();
        map.put("Username",username);
        map.put("Name",name);
        map.put("Email",email);
        map.put("Phone",phone);
        map.put("Password",password);
        map.put("Score",score);
        map.put("interest",interests);
        map.put("ProfileImg",profile);
        Log.i("My App","Adding now" + map.toString());
        AccountManager.getInstance().setUserAccount(username,password, name,score,profile);

        firebasedatabase.getReference("Users/"+username).setValue(map);
        Log.i("My App"," Added");

        Intent intent = new Intent(RegisterActivity.this, IntrestsActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);


    }
}
