package edu.uaeu.samaapplication;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.uaeu.samaapplication.Goal;
import edu.uaeu.samaapplication.util.GenUtil;

public class GoalManager {

    private static GoalManager instance = new GoalManager();
    private String nameSharedPrefID = "MyTerraApplication.CIT.AE";
    private Map<String, Goal> goalsMap = new HashMap();
    SharedPreferences sharedPref ;
    public static GoalManager getInstance(){ return instance;}
    private GoalManager(){
        // points of the actions will be retrieved from the data base "Goal Collection" (see main activity to understand)
        sharedPref = MyApp.getAppContext().getSharedPreferences(nameSharedPrefID, Context.MODE_PRIVATE );
        String[] goalInfo = GenUtil.getGoalsInfo();
        String[] goals = GenUtil.getGoals();
        for(int i=0;i<17;i++){
            int index = i+1;
            String key = "G" + index;
            int cgRes = GenUtil.getResourceByName("cg" + index,"drawable");
            int sgRes = GenUtil.getResourceByName("sg" + index,"drawable");
            int lgRes = GenUtil.getResourceByName("lg" + index,"drawable");
            String[] actions = GenUtil.getActionsByGoal("Goal"+index);
            goalsMap.put(key,new Goal(key, goals[i].substring(3).trim(),cgRes, sgRes, lgRes, goalInfo[i],
                    actions[0],actions[1],actions[2],"https://sdgs.un.org/goals/goal" + index));
        }
    }

    public Goal getGoal(String id){
        return goalsMap.get(id);

    }
    public Goal getGoal(){
        Goal go = new Goal();
        String id = sharedPref.getString("id","");
        String desc = sharedPref.getString("desc","");
        if(id == "") return null;
        go.id = id;
        go.desc = desc;
        return go;
    }

    public String getGoalDesc(String id){

        return goalsMap.get(id).desc;
    }
    public int getGoalLogo(String id){

        return goalsMap.get(id).logo;
    }

    public int getSqrGoalLogo(String id){

        return goalsMap.get(id).sqrLogo;
    }
    public int getGoalLapel(String id){

        return goalsMap.get(id).logoLapel;
    }
    public String getSqrGoalInfo(String id){

        return goalsMap.get(id).info;
    }

    public String getAction1(String id){

        return goalsMap.get(id).action1;
    }
    public String getAction2(String id){

        return goalsMap.get(id).action2;
    }
    public String getAction3(String id){

        return goalsMap.get(id).action3;
    }

    public String getLink(String id){

        return goalsMap.get(id).link;
    }


    public Goal[] getGoals(){
        Goal [] g = new Goal[goalsMap.size()];
        for(int i = 0 ; i<goalsMap.size();i++){
            g[i] = goalsMap.get("G"+(i+1));
        }

        return g;
    }

    public void setUserInterest(String[] goalIDs){   //
        //Goal g = new Goal();
        SharedPreferences.Editor editor = sharedPref.edit();
        for(String id : goalIDs) editor.putString(id,id);
        editor.commit();

    }

    public void setUserInterest(String goalID){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(goalID,goalID);
        editor.commit();
    }

    public Goal[] getUserInterestsG(){
        List<Goal> lst = new ArrayList();
        for(int i=1;i<18;i++){
            String k = "g"+i;
            String v = sharedPref.getString(k,"");
            if(v.isEmpty())continue;
            lst.add(getGoal(k));
        }
        return lst.toArray(new Goal[0]);
    }

    public String[] getUserInterests(){
        List<String> lst = new ArrayList();
        for(int i=1;i<18;i++){
            String k = "g"+i;
            String v = sharedPref.getString(k,"");
            if(v.isEmpty())continue;
            lst.add(getGoal(k).desc);
        }
        return lst.toArray(new String[0]);
    }

    public String getGoalID (String description){
        for(int i = 0 ; i<goalsMap.size();i++) {
            if (goalsMap.get("G"+(i+1)).desc.equals(description)) {
                return goalsMap.get("G"+(i+1)).id;
            }
        }
        return "G12";
    }



}

