package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class IntrestsActivity  extends AppCompatActivity {
   // SharedPreferences sharedPref = MyApp.getAppContext().getSharedPreferences("com.example.FirebaseDemo.PREFERENCE_FILE_KEY", Context.MODE_PRIVATE );
    ArrayList<String> intrests = new ArrayList<>();
    String s="";
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private String username = AccountManager.getInstance().getUserName();
    private String name = AccountManager.getInstance().getName();
    private ImageButton arrow;
   // private String [] interest = new String[17];
   // private String [] splittedList = new String[17];

    private String [] intList = new String [17];
    ArrayList <String> intrestsLst = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i("My App","Start");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intrests);
        firebaseDatabase = FirebaseDatabase.getInstance();


        arrow = findViewById(R.id.arrow);
        CheckBox cb1 = findViewById(R.id.cb1); CheckBox cb2 = findViewById(R.id.cb2);
        CheckBox cb3 = findViewById(R.id.cb3); CheckBox cb4 = findViewById(R.id.cb4);
        CheckBox cb5 = findViewById(R.id.cb5); CheckBox cb6 = findViewById(R.id.cb6);
        CheckBox cb7 = findViewById(R.id.cb7); CheckBox cb8 = findViewById(R.id.cb8);
        CheckBox cb9 = findViewById(R.id.cb9); CheckBox cb10 = findViewById(R.id.cb10);
        CheckBox cb11 = findViewById(R.id.cb11); CheckBox cb12 = findViewById(R.id.cb12);
        CheckBox cb13 = findViewById(R.id.cb13); CheckBox cb14 = findViewById(R.id.cb14);
        CheckBox cb15 = findViewById(R.id.cb15); CheckBox cb16 = findViewById(R.id.cb16);
        CheckBox cb17 = findViewById(R.id.cb17);
       // cb1.setChecked(true);

        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        Query userCheck = databaseReference.orderByChild("Username").equalTo(username);
        Log.i("My App", String.valueOf(userCheck));
        TextView welcoming = findViewById(R.id.text1);
        //Log.i("My App", welcoming.toString());
        welcoming.setText("Hi, "+ name, EditText.BufferType.EDITABLE);
        userCheck.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
            if(snapshot.exists())
                {
                    Log.i("My App", "Splitting");
                    String interest = snapshot.child(username).child("interest").getValue(String.class);
                    if(!interest.equals("")){
                    Log.i("My App", interest);
                    intList = interest.split(",");
                    Log.i("My App", "Splitted");
                    for(int i = 0; i<intList.length; i++) {
                        if(!intList[i].isEmpty()) {
                           // Log.i("My App", intList[i]);
                            intrestsLst.add(intList[i]);
                            Log.i("My App",intrestsLst.get(i));
                        }

                    }
                    if(intrestsLst.contains("No Poverty")){
                        cb1.setChecked(true);
                    }
                    if(intrestsLst.contains("Zero Hunger")){
                        cb2.setChecked(true);
                    }
                    if(intrestsLst.contains("Good Health and well-being")){
                        cb3.setChecked(true);
                    }
                    if(intrestsLst.contains("Quality Education")){
                        cb4.setChecked(true);
                    }
                    if(intrestsLst.contains("Gender Equality")){
                        cb5.setChecked(true);
                    }
                    if(intrestsLst.contains("Clean Water and sanitation")){
                        cb6.setChecked(true);
                    }
                    if(intrestsLst.contains("Affordable and Clean Energy")){
                        cb7.setChecked(true);
                    }
                    if(intrestsLst.contains("Decent Work and Economic Growth")){
                        cb8.setChecked(true);
                    }
                    if(intrestsLst.contains("Industry, Innovation and Infrastructure")){
                        cb9.setChecked(true);
                    }
                    if(intrestsLst.contains("Reduced Inequalities")){
                        cb10.setChecked(true);
                    }
                    if(intrestsLst.contains("Sustainable Cities and Communities")){
                        cb11.setChecked(true);
                    }
                    if(intrestsLst.contains("Responsible Consumption and Production")){
                        cb12.setChecked(true);
                    }
                    if(intrestsLst.contains("Climate Action")){
                        cb13.setChecked(true);
                    }
                    if(intrestsLst.contains("Life Below Water")){
                        cb14.setChecked(true);
                    }
                    if(intrestsLst.contains("Life On Land")){
                        cb15.setChecked(true);
                    }
                    if(intrestsLst.contains("Peace, Justice and Strong Institutions")){
                        cb16.setChecked(true);
                    }
                    if(intrestsLst.contains("Partnership For the Goals")){
                        cb17.setChecked(true);
                    }

                }else{
                        //Toast.makeText(IntrestsActivity.this, "No Interests",Toast.LENGTH_SHORT).show();

                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        Log.i("My App", "Here 1");
        arrow.setOnClickListener(view -> {
            if (!cb1.isChecked() && !cb2.isChecked() && !cb3.isChecked() && !cb4.isChecked() && !cb5.isChecked() && !cb6.isChecked()&& !cb7.isChecked() && !cb8.isChecked() && !cb9.isChecked() && !cb10.isChecked() && !cb11.isChecked() && !cb12.isChecked() && !cb13.isChecked() && !cb14.isChecked() && !cb15.isChecked() && !cb16.isChecked() && !cb17.isChecked()) {
                Log.i("My App", "Here 2");
                Toast.makeText(IntrestsActivity.this, "Choose at least one interest!! ",Toast.LENGTH_SHORT).show();
                //startActivity(new Intent(IntrestsActivity.this, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
            } else {
                Log.i("My App", "Here 3");
                if(cb1.isChecked()){
                    intrests.add("No Poverty");

                }if(cb2.isChecked()){
                    intrests.add("Zero Hunger");
                }
                if(cb3.isChecked()){
                    intrests.add("Good Health and well-being");
                }
                if(cb4.isChecked()){
                    intrests.add("Quality Education");
                }
                if(cb5.isChecked()){
                    intrests.add("Gender Equality");
                }
                if(cb6.isChecked()){
                    intrests.add("Clean Water and sanitation");
                }
                if(cb7.isChecked()){
                    intrests.add("Affordable and Clean Energy");
                }
                if(cb8.isChecked()){
                    intrests.add("Decent Work and Economic Growth");
                }
                if(cb9.isChecked()){
                    intrests.add("Industry, Innovation and Infrastructure");
                }
                if(cb10.isChecked()){
                    intrests.add("Reduced Inequalities");
                }
                if(cb11.isChecked()){
                    intrests.add("Sustainable Cities and Communities");
                }
                if(cb12.isChecked()){
                    intrests.add("Responsible Consumption and Production");
                }
                if(cb13.isChecked()){
                    intrests.add("Climate Action");
                }
                if(cb14.isChecked()){
                    intrests.add("Life Below Water");
                }
                if(cb15.isChecked()){
                    intrests.add("Life On Land");
                }
                if(cb16.isChecked()){
                    intrests.add("Peace, Justice and Strong Institutions");
                }
                if(cb17.isChecked()){
                    intrests.add("Partnership For the Goals");
                }
                Log.i("My App", "Here 4");

                for (int i = 0; i < intrests.size(); i++) {
                    Log.i("My App", intrests.get(i));
                    //System.out.println(intrests.get(i));
                    s= s + intrests.get(i)+ ",";
                    Log.i("My App", s);
                }
                addDatatoFirebase(s);

            }

        });



    }
    private void addDatatoFirebase(String interest) {

        //Log.i("myApp","now adding...");
       // String user = AccountManager.getInstance().getUserName();
        firebaseDatabase.getReference("Users/"+username+"/interest/").setValue(interest);
        startActivity(new Intent(IntrestsActivity.this, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
        // we are use add value event listener method

    }
}
