package edu.uaeu.samaapplication;

import java.util.ArrayList;
import java.util.List;

public class Goal {
    String id;
    String desc;
    int logo;
    int sqrLogo;
    int logoLapel;
    String info;
    String action1;
    String action2;
    String action3;
    String link;
    List<String> actions = new ArrayList();
    boolean isChecked = false;//is interested or not
    public Goal(String id, String desc, int logo, int sqrLogo, int logoLapel, String info, String action1, String action2, String action3, String link){
        this.desc = desc; this.logo = logo; this.info = info;
        this.id = id; this.sqrLogo = sqrLogo; this.logoLapel = logoLapel;
        this.action1 = action1; this.action2 = action2; this.action3 = action3;
        this.link = link;
    }
    public Goal(){}
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public int getLogo() {
        return logo;
    }
    public void setLogo(int logo) {
        this.logo = logo;
    }
    public int getSqrLogo() {
        return sqrLogo;
    }
    public void setSqrLogo(int sqrLogo) {
        this.sqrLogo = sqrLogo;
    }

    public int getLogoLapel() {
        return logoLapel;
    }

    public void setLogoLapel(int logoLapel) {
        this.logoLapel = logoLapel;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getAction1() {
        return action1;
    }

    public void setAction1(String action1) {
        this.action1 = action1;
    }

    public String getAction2() {
        return action2;
    }

    public void setAction2(String action2) {
        this.action2 = action2;
    }

    public String getAction3() {
        return action3;
    }
    public void addAction(String action){ this.actions.add(action);}
    public void addActions(String[] actions){
        for(String a : actions) this.actions.add(a);
    }
    public List<String> getActions(){ return this.actions;}

    public void addActions(List<String> actions){
        this.actions.addAll(actions);
    }
    public String getAction(int index){ return this.actions.get(index);}
    public int getActionIndex(String action){
        return this.actions.indexOf(action);
    }
    public void setAction3(String action3) {
        this.action3 = action3;
    }
    public String getLink() {
        return link;
    }
    public void setLink(String link) {
        this.link = link;
    }

    @Override
    public String toString() {
        return "Goal{" +
                "id='" + id + '\'' +
                ", desc='" + desc + '\'' +
                ", logo=" + logo +
                ", sqrLogo=" + sqrLogo +
                ", logoLapel=" + logoLapel +
                ", info='" + info + '\'' +
                ", action1='" + action1 + '\'' +
                ", action2='" + action2 + '\'' +
                ", action3='" + action3 + '\'' +
                ", link='" + link + '\'' +
                ", actions=" + actions +
                ", isChecked=" + isChecked +
                '}';
    }
}
