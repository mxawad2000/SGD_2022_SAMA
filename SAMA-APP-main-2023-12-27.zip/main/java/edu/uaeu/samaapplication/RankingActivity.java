package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import edu.uaeu.samaapplication.Adapter.PostAdapter;
import edu.uaeu.samaapplication.Adapter.RankingAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
//import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class RankingActivity extends AppCompatActivity {

    private RecyclerView recyclerViewUsers;
    private RankingAdapter rankAdapter;
    private List<User> userList;
    private List<User> oldUserList;
    private ImageView userProfileImage;
    private TextView name;
    private TextView score;
    private TextView rank;
    private ImageView arrow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_ranking);


       name = findViewById(R.id.name_ranking);
       score = findViewById(R.id.score_ranking);
       rank = findViewById(R.id.rank_ranking);
        userProfileImage = findViewById(R.id.image_profile_ranking);
        arrow = findViewById(R.id.return_arrow_ranking);

        recyclerViewUsers = findViewById(R.id.recycler_view_ranking);
        recyclerViewUsers.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);
        linearLayoutManager.setReverseLayout(true);
        recyclerViewUsers.setLayoutManager(linearLayoutManager);
        userList = new ArrayList<>();
        oldUserList= new ArrayList<>();
        rankAdapter = new RankingAdapter(this , userList);
        recyclerViewUsers.setAdapter(rankAdapter);

        getUserInfo();
        getUsers();

        arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }



    private void getUserInfo() {
        FirebaseDatabase.getInstance().getReference("Users").child(AccountManager.getInstance().getUserName()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map<String,String> m = (Map<String, String>) snapshot.getValue();
                User user = (snapshot.getValue(User.class));
                Log.i("My App","this usersnapshot: "+ snapshot.getValue());
                //  Log.i("My App", "datasnapshot3333: " +post.toString());
                user.setUsername(m.get("Username"));
                user.setName(m.get("Name"));
                user.setImage(m.get("ProfileImg"));
                user.setScore(String.valueOf(m.get("Score")));

                // User user = snapshot.getValue(User.class);
                score.setText(user.getScore());
                name.setText(user.getName());

                Log.i("My App","getImage - RankingActivity : " + user.getImage());

                if (user.getImage().equals("default")) {
                    Log.i("My App", "From DB Image - Notification Adapter user default image profile : " + user.getImage());
                    userProfileImage.setImageResource(R.drawable.imgpro);


                } else {
                    Log.i("My App", "From DB Image - Notification Adapter user has an image profile : " + user.getImage());
                    byte[] decodedString = Base64.decode(user.getImage(), Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    user.setImageBitmap(bitmap);
                    if (bitmap != null)
                        userProfileImage.setImageBitmap(user.getImageBitmap());
                }



            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void getUsers() {
        FirebaseDatabase.getInstance().getReference("Users");
        Query query = FirebaseDatabase.getInstance().getReference("Users").orderByChild("Score");

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot s : snapshot.getChildren()){
                    Map<String,String> m = (Map<String, String>) s.getValue();
                    User user = (snapshot.getValue(User.class));
                    //  Log.i("My App", "datasnapshot3333: " +post.toString());
                    user.setUsername(m.get("Username"));
                    user.setName(m.get("Name"));
                    user.setImage(m.get("ProfileImg"));
                    user.setScore(String.valueOf(m.get("Score")));
                    if (user.getImage().equals("default")) {
                        Log.i("My App", "From DB Image - Notification Adapter user default image profile : " + user.getImage());

                    } else {
                        Log.i("My App", "From DB Image - Notification Adapter user has an image profile : " + user.getImage());
                        byte[] decodedString = Base64.decode(user.getImage(), Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        user.setImageBitmap(bitmap);

                    }

                    Log.i("My App","Ranking_username: "+ user.getUsername());
                    Log.i("My App","Ranking_score: "+ user.getScore());

                    oldUserList.add(user);
                }

                Log.i("My App","Ranking_List size : "+ oldUserList.size());
                Log.i("My App","Ranking_List  : "+ oldUserList.iterator());
                for (int i = 0 ; i<oldUserList.size();i++){
                    Log.i("My App","Ranking_old List  : "+ oldUserList.get(i).getUsername());
                    Log.i("My App","Ranking_old List  : "+ oldUserList.get(i).getScore());
                }
                int min = -100;
                int pos = -100;

        for(int j = 0 ;j<oldUserList.size();j = 0) {
            min = -100;
            pos = -100;
            for (int i = 0; i < oldUserList.size(); i++) {
                if (min < Integer.parseInt(oldUserList.get(i).getScore())) {
                    min = Integer.parseInt(oldUserList.get(i).getScore());
                    pos = i;
                }

            }
            userList.add(oldUserList.get(pos));
            oldUserList.remove(pos);

        }
                Log.i("My App","Ranking_new sorted List  : "+ userList.size());
                for (int i = 0 ; i<userList.size();i++){
                    if(userList.get(i).getUsername().equals(AccountManager.getInstance().getUserName())){
                        rank.setText(String.valueOf((i+1)));
                    }
                    Log.i("My App","Ranking_new sorted List  : "+ userList.get(i).getUsername());
                    Log.i("My App","Ranking_new sorted list  : "+ userList.get(i).getScore());
                }

                Collections.reverse(userList);
                rankAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

}