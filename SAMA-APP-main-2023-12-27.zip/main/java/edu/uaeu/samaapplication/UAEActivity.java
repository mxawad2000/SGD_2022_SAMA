package edu.uaeu.samaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;

public class UAEActivity extends AppCompatActivity {
    private WebView twitter;
    private ImageView back;
    String twitterUrl = "http://twitter.com/UAESDGs";
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uaeactivity);
        Bundle bundle = getIntent().getExtras();
        if(bundle !=null && bundle.containsKey("q")){
            Log.i(MyApp.LOG_STR,"q=" + bundle.get("q"));
            twitterUrl = String.format("https://twitter.com/search?q=%s (to:UAESDGs)",bundle.getString("q"));
        }
        twitter = (WebView) findViewById(R.id.twitter);
        twitter.setWebViewClient(new WebViewClient());
        twitter.getSettings().setJavaScriptEnabled(true);
        twitter.getSettings().setDomStorageEnabled(true);
        twitter.loadUrl(twitterUrl);
        back = findViewById(R.id.back_arrow_twitter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }
}