package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import edu.uaeu.samaapplication.dbinit.FirestoreDBManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirstPage extends AppCompatActivity {
    private ImageView iconImage;
    private LinearLayout linearLayout;
    private Button register;
    private Button login;

    // FirebaseAuth mAuth;

   // private SharedPreferences sharedPref = getSharedPreferences("com.example.FirebaseDemo.PREFERENCE_FILE_KEY", Context.MODE_PRIVATE );


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);

        iconImage = findViewById(R.id.icon_image);
        Log.i("My App", "Hello there!");
        //iconImage = null;
       linearLayout = findViewById(R.id.linear_layout);
        register =  findViewById(R.id.register);
        login = findViewById(R.id.login);

        login.setOnClickListener(v -> startActivity(new Intent(FirstPage.this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK| Intent.FLAG_ACTIVITY_CLEAR_TOP)));
        register.setOnClickListener(view -> startActivity(new Intent(FirstPage.this, RegisterActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP)));
        Log.i(MyApp.LOG_STR,"USER/USER:" + AccountManager.getInstance().getCurrentUser());

        if (AccountManager.getInstance().getUserName() != null){
            FirebaseDatabase.getInstance().getReference().child("Users").child(AccountManager.getInstance().getUserName()).child("Score").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        AccountManager.getInstance().setUserScore(Integer.parseInt(snapshot.getValue().toString()));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
            startActivity(new Intent(this, HomeActivity.class));
        }
        FirestoreDBManager.getInstance();
    }
    private class MyAnimationListener implements Animation.AnimationListener{
        @Override
        public void onAnimationStart(Animation animation) {
        }
        @Override
        public void onAnimationEnd(Animation animation) {
            iconImage.clearAnimation();
            iconImage.setVisibility(View.INVISIBLE);
            linearLayout.animate().alpha(1f).setDuration(2000);  //1sec
        }
        @Override
        public void onAnimationRepeat(Animation animation) {

        }
    }}