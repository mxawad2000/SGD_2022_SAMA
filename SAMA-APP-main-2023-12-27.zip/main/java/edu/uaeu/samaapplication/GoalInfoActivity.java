package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.text.method.ScrollingMovementMethod;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import edu.uaeu.samaapplication.Adapter.PhotoAdapter;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class GoalInfoActivity extends AppCompatActivity {

    private TextView action1;
    private TextView action2;
    private TextView action3;

    private TextView action1point;
    private TextView action2point;
    private TextView action3point;

    private TextView info;
    private Toolbar label;
    private Button actionsBtn;
    private Button postsBtn;
    private LinearLayout Actions_info ;

    private RecyclerView posts;
    private PhotoAdapter photoAdapter;
    private List<Post> myPhotolist;
    private TextView readmore;

   // private TextView text;

     private ImageView arrow;
    String goalId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_info);

        SharedPreferences prefs = this.getSharedPreferences("PREFS" , Context.MODE_PRIVATE);
        goalId = prefs.getString("goalid" , "none");



        arrow = findViewById(R.id.return_arrow_info);
        readmore = findViewById(R.id.readmore);

        action1 = findViewById(R.id.myImageViewText);
        action2 = findViewById(R.id.myImageViewText2);
        action3 = findViewById(R.id.myImageViewText3);

        action1point = findViewById(R.id.Actin1Point);
        action2point = findViewById(R.id.Actin2Point);
        action3point = findViewById(R.id.Actin3Point);

        actionsBtn = findViewById(R.id.actoins_b);
        postsBtn = findViewById(R.id.related_posts);
        Actions_info = findViewById(R.id.Actions_info);
        posts = findViewById(R.id.recycler_view_relatedPosts);

        posts.setHasFixedSize(true);
        posts.setLayoutManager(new GridLayoutManager(this,  3));
        myPhotolist = new ArrayList<>();
        photoAdapter = new PhotoAdapter(this,myPhotolist);
        posts.setAdapter(photoAdapter);

        info = findViewById(R.id.actionInfo);
        label = findViewById(R.id.goal_label);

        action1.setText(GoalManager.getInstance().getAction1(goalId));
        action2.setText(GoalManager.getInstance().getAction2(goalId));
        action3.setText(GoalManager.getInstance().getAction3(goalId));

        info.setText(GoalManager.getInstance().getSqrGoalInfo(goalId));
        //info.setMovementMethod(new ScrollingMovementMethod());
        label.setBackgroundResource(GoalManager.getInstance().getGoalLapel(goalId));

        FirebaseFirestore.getInstance().collection("Goals").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (QueryDocumentSnapshot document : task.getResult()) {
                    Log.d("My App", document.getId() + " => " + document.getData());
                    if (document.getData().containsKey(GoalManager.getInstance().getAction1(goalId))) {
                        //Log.i("My App",document.getData());
                        action1point.setText(document.get(GoalManager.getInstance().getAction1(goalId))+" Points");
                        action2point.setText(document.get(GoalManager.getInstance().getAction2(goalId))+" Points");
                        action3point.setText(document.get(GoalManager.getInstance().getAction3(goalId))+" Points");

                    }

                }
            }

        });
        readmore.setPaintFlags(readmore.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        readmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(GoalManager.getInstance().getLink(goalId)));
                startActivity(browser);
            }
        });
        /*
        readmore.setText("https://sdgs.un.org/goals/goal1");
        readmore.setAutoLinkMask();
        readmore.setMovementMethod(LinkMovementMethod.getInstance());

         */
        actionsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Actions_info.setVisibility(View.VISIBLE);
                posts.setVisibility(View.GONE);
                actionsBtn.setTextColor(getResources().getColor(R.color.black));
                postsBtn.setTextColor(getResources().getColor(R.color.gray));

            }
        });

        postsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Actions_info.setVisibility(View.GONE);
                posts.setVisibility(View.VISIBLE);
                actionsBtn.setTextColor(getResources().getColor(R.color.gray));
                postsBtn.setTextColor(getResources().getColor(R.color.black));
                getPhotos(goalId);
                if(myPhotolist.isEmpty()){

                }
            }
        });




        arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void getPhotos(String goalid) {

        Log.i("My App", "SearchGoal : In");
        //recyclerViewGoals.setVisibility(View.VISIBLE);
        //  FirebaseDatabase.getInstance().getReference().child("Users").child(AccountManager.getInstance().getUserName()).child("posts");
        //FirebaseDatabase.getInstance().getReference("Goals").orderByChild("Goal").startAt(enteredGoal).endAt(enteredGoal + "\uf8ff");
        Log.i("My App","Goal ID String: "+ goalid);
        //Query query =  FirebaseDatabase.getInstance().getReference("Goals").child();
        //Log.i("My App", "Search Fragment Query  : " + query);
        FirebaseDatabase.getInstance().getReference("Goals").child(goalid).addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    Log.i("My App", "Goal Posts 6 : Snapshot");
                    Log.i("My App", "Goal Posts snapshot: " + snapshot.getValue());

                    for (DataSnapshot s : snapshot.getChildren()) {
                        Log.i("My App", "Goal Posts 7 : Snapshot s ");
                        Log.i("My App", "Goal Posts 8 data snapshot ALL: " + s.getValue());
                        Map<String, String> m = (Map<String, String>) s.getValue();
                        Post post = (snapshot.getValue(Post.class));
                        Log.i("My App", "datasnapshot : " + post.toString());
                        post.setAction(m.get("Action"));
                        post.setGoal(m.get("Goal"));
                        post.setDescription(m.get("Description"));
                        post.setLike(m.get("Like"));
                        post.setGoalId(m.get("Goal ID"));
                        post.setPrivate(Boolean.valueOf(m.get("Private")));
                        post.setPoint(m.get("Point"));
                        post.setPublisher(m.get("Publisher"));
                        post.setDisLike(m.get("Dislike"));
                        post.setPostId(m.get("Post ID"));
                        post.setImage(m.get("Image"));
                        post.setLink(m.get("Link"));
                        Log.i("My App", "Goal Posts IMAGE: " + post.getImage());

                        byte[] decodedString = Base64.decode(post.getImage(), Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        post.setImageBitmap(decodedByte);
                        Log.i("My App", "Goal Posts IMAGE: " + post.getImageBitmap());

                        Log.i("My App", "Post details: " + post.getGoalId().contains(goalid) + " , " + post.getPrivate());
                        if (!post.getPrivate()) {
                            if (post.getGoalId().contains(goalid)) {
                                Log.i("My App", "Goal Posts 9 : getGoal ");
                                myPhotolist.add(post);
                            }

                        }
                    }
                 //   Log.i("My App", "Goal Posts post list SIZE  : " + myPhotolist.size());
                   // Log.i("My App", "Goal Posts post list  : " + myPhotolist.get(0).toString());
                    Collections.reverse(myPhotolist);
                    photoAdapter.notifyDataSetChanged();
                    Log.i("My App", "Goal Posts After Notify:<" + myPhotolist.size() + "> adapter size<" + photoAdapter.getItemCount() + " >..... ");
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}