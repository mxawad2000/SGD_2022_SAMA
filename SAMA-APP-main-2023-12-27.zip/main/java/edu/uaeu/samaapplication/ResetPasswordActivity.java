package edu.uaeu.samaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.TimeUnit;


public class ResetPasswordActivity extends AppCompatActivity {
    private EditText phone,OTP;
    private Button BtngenerateOTP, BtnVerifyOTP;
    private ImageView back;
    private FirebaseAuth mAuth;
    private String vericationID;
    private DatabaseReference databaseReference;
    private String number2;
    private ProgressBar simpleProgressBar ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
        phone = findViewById(R.id.phone);
        OTP = findViewById(R.id.OTP);
        BtngenerateOTP = findViewById(R.id.BtngenerateOTP);
        BtnVerifyOTP = findViewById(R.id.BtnVerifyOTP);
        back = findViewById(R.id.backArrow_resetPass);
        mAuth = FirebaseAuth.getInstance();
        simpleProgressBar = (ProgressBar) findViewById(R.id.simpleProgressBar_reset);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        BtngenerateOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                simpleProgressBar.setVisibility(View.VISIBLE);
                if(TextUtils.isEmpty(phone.getText().toString())){
                    simpleProgressBar.setVisibility(View.GONE);
                    Toast.makeText(ResetPasswordActivity.this, "Enter valid phone number", Toast.LENGTH_SHORT).show();

                }else{

                    String number= phone.getText().toString();
                    number2= "0"+number;
                    Log.i("My App", "Phone Number is : "+number2);
                    databaseReference = FirebaseDatabase.getInstance().getReference("Users");
                    Query userCheck = databaseReference.orderByChild("Phone").equalTo(number2);
                    userCheck.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                sendverificationcode(number);
                                Log.i("My App", "snapshot Phone:  " + snapshot.child("Phone").getValue(String.class));


                            }
                            else{
                                simpleProgressBar.setVisibility(View.GONE);
                                Toast.makeText(ResetPasswordActivity.this, "Phone Number Doesn't Exist ",Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });



                    //sendverificationcode(number);
                }


            }
        });

        BtnVerifyOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                simpleProgressBar.setVisibility(View.VISIBLE);
                if(TextUtils.isEmpty(OTP.getText().toString())){
                    simpleProgressBar.setVisibility(View.GONE);
                    Toast.makeText(ResetPasswordActivity.this, "wrong OTP Entered", Toast.LENGTH_SHORT).show();

                }else{
                    verifycode(OTP.getText().toString());
                }


            }
        });

    }

    private void sendverificationcode(String phoneNumber) {
        simpleProgressBar.setVisibility(View.VISIBLE);
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+971"+phoneNumber)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // Activity (for callback binding)
                        .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks
            mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {
            final String code = credential.getSmsCode();
            if(code!=null)
            {
                verifycode(code);
            }

        }

        @Override
        public void onVerificationFailed(@NonNull FirebaseException e) {

            Toast.makeText(ResetPasswordActivity.this, "Verification Failed ! ", Toast.LENGTH_SHORT).show();
            simpleProgressBar.setVisibility(View.GONE);
        }

        @Override
        public void onCodeSent(@NonNull String s,
                               @NonNull PhoneAuthProvider.ForceResendingToken token) {

            super.onCodeSent(s, token);
            vericationID= s;
            simpleProgressBar.setVisibility(View.GONE);


        }
    };


    private void verifycode(String Code) {
        PhoneAuthCredential credential= PhoneAuthProvider.getCredential(vericationID, Code);
        signinbyCredintials(credential);

    }

    private void signinbyCredintials(PhoneAuthCredential credential) {
        FirebaseAuth firebaseAuth= FirebaseAuth.getInstance();
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(ResetPasswordActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                            //startActivity(new Intent(ResetPasswordActivity.this,NewPasswordActivity.class));
                            Intent intent = new Intent(ResetPasswordActivity.this, NewPasswordActivity.class);
                            intent.putExtra("phone", number2);
                            startActivity(intent);
                        }else{
                            Toast.makeText(ResetPasswordActivity.this, "Wrong OTP!!!!", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if(currentUser!=null){
            startActivity(new Intent(ResetPasswordActivity.this, NewPasswordActivity.class));
            finish();
        }
    }
}