package edu.uaeu.samaapplication;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
//import com.squareup.picasso.Picasso;

//import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class EditProfileActivity extends AppCompatActivity {

    private ImageView close;
    private ImageView image_profile;

    private TextView tv_change;
    private EditText name;
    private EditText username;
    private EditText email;
    private EditText phone;

    private Button save;
    private Button changePassword;
    private  Uri selectedImage;
    private ImageView imageView;
    private Bitmap bitmap;
    private String imageEncoded;
    Map<String, String> m;

    private static final int RESULT_LOAD_IMAGE = 123;
    public static final int IMAGE_CAPTURE_CODE = 654;


    ExifInterface exif;


    //private Button load;

    //ImageView iv_pick_image;
    ActivityResultLauncher<String> mGetContent;

    //private AccountManager user = AccountManager.getInstance();
    private String Username = AccountManager.getInstance().getUserName();


    private Bitmap uriToBitmap(Uri selectedFileUri) {
        try {
            ParcelFileDescriptor parcelFileDescriptor = getContentResolver().openFileDescriptor(selectedFileUri, "r");
            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
            Bitmap image = BitmapFactory.decodeFileDescriptor(fileDescriptor);

            parcelFileDescriptor.close();
            return image;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  null;
    }

    private void encodeBitmapAndSaveToFirebase(Bitmap photo) {

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        photo.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        imageEncoded = Base64.encodeToString(byteArray, Base64.DEFAULT);

    }
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 0) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    protected void onActivityResult (int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null){

            selectedImage = data.getData();
            Log.i("My App","Selected Iamge: "+selectedImage);
            //imageView.setImageURI(image_uri);
            bitmap = uriToBitmap(selectedImage);// it works but don;t save to database + takes a lot of time to put the image in the image view
           // bitmap = StringToBitMap(String.valueOf(selectedImage));// does not work


            Matrix matrix = new Matrix();
            matrix.postRotate(0);
            Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth(), bitmap.getHeight(), true);
            Bitmap rotatedBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0, scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix, true);


            imageView.setImageBitmap(rotatedBitmap);
            Bitmap b = getResizedBitmap(rotatedBitmap, 500);// 1000 is too large it will start lagging
            encodeBitmapAndSaveToFirebase(b);
        }

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);



        close = findViewById(R.id.close);
        name = findViewById(R.id.name);
        username = findViewById(R.id.username);
        username.setEnabled(false);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        save = findViewById(R.id.save);
        changePassword = findViewById(R.id.change_password_edit);
        tv_change = findViewById(R.id.tv_change);
        imageView = findViewById(R.id.image_profile);


        //Toast.makeText(EditProfileActivity.this, "You can't change your username! Contact admin.", Toast.LENGTH_SHORT).show();

        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(view.getContext(), ChangePasswordInActivity2.class);
                view.getContext().startActivity(intent);
            }
        });

        FirebaseDatabase.getInstance().getReference("Users").child(Username).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {

                    m = (Map<String, String>) dataSnapshot.getValue();
                    User u = (dataSnapshot.getValue(User.class));

                    name.setText(m.get("Name"));
                    username.setText(m.get("Username"));
                    email.setText(m.get("Email"));
                    phone.setText(m.get("Phone"));

                    Log.i("My App", " Image Profile - EditProfileActivity : " + m.get("ProfileImg"));

                    if (m.get("ProfileImg").equals("default")) {
                        Log.i("My App", "From DB Image - EditProfileActivity : " + AccountManager.getInstance().getProfileImg());
                        Log.i("My App", "Drawable Image - EditProfileActivity : " + R.drawable.imgpro);
                        imageEncoded = m.get("ProfileImg");
                        imageView.setImageResource(R.drawable.imgpro);
                        //Picasso.get().load(R.drawable.imgpro).into(imageView);

                    } else {
                        Log.i("My App", "User has a ProfileImg- EditProfileActivity: " + m.get("ProfileImg") + "Account manager profimag: " + AccountManager.getInstance().getProfileImg());
                        imageEncoded = m.get("ProfileImg");
                        byte[] decodedString = Base64.decode(m.get("ProfileImg"), Base64.DEFAULT);
                        bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        Bitmap b = getResizedBitmap(bitmap, 500); // 1000 is too large it will start lagging
                        encodeBitmapAndSaveToFirebase(b);
                        //getResizedBitmap(bitmap, 500);
                        if (bitmap != null)
                            Log.i("My App", "User has a ProfileImg- EditProfileActivity Bitmap: " + bitmap.toString());
                        imageView.setImageBitmap(b);

                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EditProfileActivity.this, ProfileActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));

                //finish();
            }
        });



        tv_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent, RESULT_LOAD_IMAGE);
            }
        });




        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("My App", " Image Profile (Save)  - EditProfileActivity : " + m.get("ProfileImg"));
                Log.i("My App", " imageEncoded  - EditProfileActivity : " + imageEncoded);
                updateProfile(name.getText().toString() , email.getText().toString(),phone.getText().toString(),imageEncoded); //here was selectedImage
                Toast.makeText(EditProfileActivity.this, "Saved Successfully!!", Toast.LENGTH_SHORT).show();

            }
        });
    }


    private void updateProfile(String name, String email , String phone, String img)  {

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(Username);
        HashMap<String , Object> hashMap = new HashMap<>();
        hashMap.put("Name" , name);
        hashMap.put("Email" , email);
        hashMap.put("Phone" , phone);
       //hashMap.put("Usernmae" , m.get("ProfileImg"));
        hashMap.put("ProfileImg" ,img);

        AccountManager.getInstance().setProfileImg(img);
        AccountManager.getInstance().setName(name);
        reference.updateChildren(hashMap);



    }


}
