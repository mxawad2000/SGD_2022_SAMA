package edu.uaeu.samaapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import edu.uaeu.samaapplication.Adapter.PhotoAdapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class GoalPosts extends AppCompatActivity {

    private TextView goalName;
    private ImageView back;
    private RecyclerView goalPosts;

    private PhotoAdapter photoAdapter;
    private List<Post> myPhotolist;
    private Context context;
    String goalid;
   // private TextView text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_posts);
        context = this;
      //  text = findViewById(R.id.Text);

        goalName = findViewById(R.id.goal_description);
        back = findViewById(R.id.return_arrow);
        goalPosts = findViewById(R.id.recycler_view_goal_posts);

        goalPosts.setHasFixedSize(true);
        goalPosts.setLayoutManager(new GridLayoutManager(context, 3));
        myPhotolist = new ArrayList<>();
        photoAdapter = new PhotoAdapter(context,myPhotolist);
        goalPosts.setAdapter(photoAdapter);
        SharedPreferences prefs = context.getSharedPreferences("PREFS" , Context.MODE_PRIVATE);
        goalid = prefs.getString("goalid" , "none");
        Log.i("My App","Goal ID String: "+ goalid);

        goalName.setText(GoalManager.getInstance().getGoalDesc(goalid));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        getPhotos(goalid);

    }

    private void getPhotos(String goalId) {

        Log.i("My App", "SearchGoal : In");
        Log.i("My App","Goal ID String: "+ goalId);
        FirebaseDatabase.getInstance().getReference("Goals").child(goalId).addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    myPhotolist.clear();
                    for (DataSnapshot s : snapshot.getChildren()) {
                        Log.i("My App", "Goal Posts 7 : Snapshot s ");
                        Log.i("My App", "Goal Posts 8 data snapshot ALL: " + s.getValue());
                        Map<String, String> m = (Map<String, String>) s.getValue();
                        Post post = (snapshot.getValue(Post.class));
                        Log.i("My App", "datasnapshot : " +post.toString());
                        post.setAction(m.get("Action"));
                        post.setGoal(m.get("Goal"));
                        post.setDescription(m.get("Description"));
                        post.setLike(m.get("Like"));
                        post.setGoalId(m.get("Goal ID"));
                        post.setPrivate(Boolean.valueOf(m.get("Private")));
                        post.setPoint(m.get("Point"));
                        post.setPublisher(m.get("Publisher"));
                        post.setDisLike(m.get("Dislike"));
                        post.setPostId(m.get("Post ID"));
                        post.setImage(m.get("Image"));
                        post.setLink(m.get("Link"));
                        if(post.getImage()!=null) {
                            byte[] decodedString = Base64.decode(post.getImage(), Base64.DEFAULT);
                            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                            post.setImageBitmap(decodedByte);
                            Log.i("My App", "Goal Posts IMAGE: " + post.getImageBitmap());
                        }else{
                            Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.img_not_available);
                            post.setImageBitmap(largeIcon);
                        }
                        if (!post.getPrivate()) {
                            if (post.getGoalId().contains(goalid)) {
                                Log.i("My App", "Goal Posts 9 : getGoal ");
                                myPhotolist.add(post);
                            }
                        }
                    }
                    Log.i("My App", "Goal Posts post list SIZE  : " + myPhotolist.size());
                    Log.i("My App", "Goal Posts post list  : " + myPhotolist.get(0).toString());
                    Collections.reverse(myPhotolist);
                    photoAdapter.notifyDataSetChanged();
                    Log.i("My App", "Goal Posts After Notify:<" + myPhotolist.size() + "> adapter size<" + photoAdapter.getItemCount() + " >..... ");
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}